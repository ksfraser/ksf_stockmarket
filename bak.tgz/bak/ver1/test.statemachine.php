<?php

	//Test state machine file to eventually be autogen'd

require_once('class.genericstateactions.php');
	
class test_statemachine extends statemachine
{
	//currentstate => nextstate
	var $state = array ('start' => 'intermediate', 
					'intermediate' => 'end', 
					'end' => '');
	//currentstate => action
	var $action = array( 'start' => 'state_move',
				'intermediate' => 'state_move',
				'end' => 'state_end');
	//currentstate => trigger
	var $trigger = array( 'start' => 'insert',
				'intermediate' => 'auto',
				'end' => 'auto');
	//currentstate => description
	var $description = array( 'start' => 'desc',
				'intermediate' => 'desc',
				'end' => 'desc');
	function test_statemachine()
	{
		parent::__constructor();
	//currentstate => nextstate
	$state = array ('start' => 'intermediate', 
				'intermediate' => 'end', 
				'end' => '');
	//currentstate => action
	$action = array( 'start' => 'state_move',
			'intermediate' => 'state_move',
			'end' => 'state_end');
	//currentstate => trigger
	$trigger = array( 'start' => 'insert',
			'intermediate' => 'auto',
			'end' => 'auto');
	//currentstate => description
	$description = array( 'start' => 'desc',
			'intermediate' => 'desc',
			'end' => 'desc');
		return;
	}
	function __constructor()
	{
		return $this->test_statemachine();
	}
}
