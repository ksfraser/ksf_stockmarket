<?

class db
{
	var $server;
	var $username;
	var $password;
	var $database;
	var $table;
	var $query;
	var $connection;
	var $result;
	var $rows = array();
	var $lastid;
	var $debug_set = 0;
	var $error;
	var $rowcount;

	
function SetServer($server)
{
	$this->server = $server;
	if ($this->debug_set) {
		echo ('Setting Server: ' . $this->server . '<br />');
	}
}

function SetUsername($username)
{
	$this->username = $username;
	if ($this->debug_set) {
		echo ('Setting UserName: ' . $this->username . '<br />' );
	}
}

function SetPassword($password)
{
	$this->password = $password;
	if ($this->debug_set) {
		echo ('Setting Password: <br />');
	}
}

function SetDatabase($database)
{
	$this->database = $database;
	if ($this->debug_set) {
		echo ('Setting Database: ' . $this->database . '<br />' );
	}
}

function SetTable($table)
{
	$this->table = $table;
	if ($this->debug_set) {
		echo ('Setting Table: ' . $this->table . '<br />' );
	}
}

function SetQuery($query)
{
	
	$this->query = $query;
	if ($this->debug_set) {
		echo ('Setting Query: ' . $this->query . '<br />' );
	}
}

function SetDebug($debug)
{
	$this->debug_set = $debug;
	if ($this->debug_set) {
		echo ('Setting Query: ' . $this->query . '<br />' );
	}
}


function db($server, $username, $password, $database)
{
	$this->SetServer($server);
	$this->SetUsername($username);
	$this->SetPassword($password);
	$this->SetDatabase($database);
}

}

class my_db extends db
{

function my_db($server, $username, $password, $database)
{
	$this->SetServer($server);
	$this->SetUsername($username);
	$this->SetPassword($password);
	$this->SetDatabase($database);
	if ($this->debug_set) {
		echo ('Set defaults, going to connect<br />');
	}
	$this->Connect();
	$this->error = 0;
}

function Connect()
{
	$this->connection = mysql_connect($this->server, $this->username, $this->password);
 	if (!$this->connection) {
    	 die( '<p>Unable to connect to the data base server ' . $this->server . ' at this time.</p><br />Err:' . mysql_error() . '<br />' );
 	}
	else 
	{
		//echo "good db connection";
	}
 	if (! @mysql_select_db($this->database) ) {
      	  echo( '<p>Unable to locate the database ' . $this->database . ' at this time.</p>' );
    	}
}   

function enddb()
{
	//mysql_free_result($this->result);
	mysql_close($this->connection);
}

function Query()
{
	
	$this->result = mysql_query($this->query);
	if (!$this->result) 
	{
		$this->error = mysql_error();
		//die('<p>Error performing query: ' .  mysql_error() . '</p>');
		echo "<p>Error performing query: ";
	       	$ERRmsg = mysql_error();
		echo "$ERRmsg</p><br />";
	}
	$this->rowcount = mysql_affected_rows($this->connection);
	$this->lastid = mysql_insert_id();
	//echo "Rows: $this->rowcount";
	$this->error = 0;
}

function ResultToDDL($value, $description, $desc2 = "")
{
	if (!$description)
	{
		$description = $value;
	}
	if ($desc2 == NULL)
	{
		$desc2 = "";
	}
	$DDL = new DropDownList();
	$count = 0;
   	while ( $row = mysql_fetch_array( $this->result ))
	{
	  if ($row)
	  {
		require_once('page.php');  
	 	$option[$count] = new DropDownOption();
		$option[$count]->SetValue( $row[$value] );
		if ($desc2)
		{
			$text = $row[$description] . ' - ' . $row[$desc2];
			$option[$count]->SetDisplayText( $text );
		}
		else
		{
        		$option[$count]->SetDisplayText( $row[$description] );
		}
		$DDL->SetOption($option[$count]);
		$count = $count + 1;	
	  }
 	}
	return $DDL;
}

function FetchRow()
{
	$row = mysql_fetch_array( $this->result );
	return $row;
}

function ResultToRows()
{
	$this->rowcount = 0;
	while ( $row = mysql_fetch_array( $this->result ))
	{
	  if ($row)
	  {
		  $this->rows[] = $row;
		  $this->rowcount = $this->rowcount + 1;
	  }
 	}
}

function DuplicateTable($SrcTable, $DstTable)
{
	$this->SetQuery('Select * from $SrcTable');
	$this->Query();
	$row = $this->FetchRow();
	$query = "INSERT INTO $DstTable (" . implode(", ",array_keys($row)) . ") VALUES ('" . implode("', '",array_values($row)) . "')";
	$this->SetQuery($query);
	$this->Query();
	return $this->rows;
}

function ResultToTable($array)
{
	require_once('../page.php');  
	$Table = new Table();
	$count = 0;
	$rowcount=0;
	$trow[$rowcount] = new TRow();
	$tbody = new TBody();
	$garray = $array;
   	while ( $row = mysql_fetch_array( $this->result ))
	{
	  if ($row)
	  {
	    while (list($display, $field) = each($garray))
	    {
	      $option[$count] = new RowDataCell();
	      $option[$count]->SetDisplayText( $row[$field] );

 	      $trow[$rowcount]->SetOption($option[$count]);
	      $count = $count + 1;	
	      
	    }
	    $tbody->SetOption($trow[$rowcount]);
	    $rowcount = $rowcount + 1;
	    $trow[$rowcount] = new TRow();
	    $garray = $array;
	    
	  }
 	}
	if ($count < 1)
	  return $Table;
	$trow2 = new TRow();
	while (list($display, $field) = each($array))
	  {
	      $option[$count] = new RowHeaderCell();
	      $option[$count]->SetDisplayText( $display );
 	      $trow2->SetOption($option[$count]);
	      $count = $count + 1;	
	  }
	$Table->SetTHead($trow2);
	$Table->SetTBody($tbody);
	return $Table;
}

}  //Class

?>
