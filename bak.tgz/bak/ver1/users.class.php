<?php 
//this script may only be included - so its better to die if called directly.
if (strpos($_SERVER["SCRIPT_NAME"],basename(__FILE__)) !== false) {
  header("location: index.php");
  exit;
}

require_once('class.generictable.php');
require_once('users.class.inc.php');
class users extends generictable{
         function __constructor()
         {
         $this->querytablename = 'users';
         $this->fieldspec['emailaddress']['metadata_id'] = '2503';
         $this->fieldspec['emailaddress']['table_name'] = 'users';
         $this->fieldspec['emailaddress']['column_name'] = 'emailaddress';
         $this->fieldspec['emailaddress']['pretty_name'] = 'Email Address';
         $this->fieldspec['emailaddress']['abstract_data_type'] = 'string';
         $this->fieldspec['emailaddress']['db_data_type'] = 'varchar';
         $this->fieldspec['emailaddress']['field_null'] = 'NO';
         $this->fieldspec['emailaddress']['field_key'] = '0';
         $this->fieldspec['emailaddress']['extra_sql'] = ' ';
         $this->fieldspec['emailaddress']['html_form_type'] = 'char';
         $this->fieldspec['emailaddress']['html_form_options'] = ' ';
         $this->fieldspec['emailaddress']['html_form_explanation'] = ' ';
         $this->fieldspec['emailaddress']['help_text'] = ' ';
         $this->fieldspec['emailaddress']['mandatory_p'] = 'Y';
         $this->fieldspec['emailaddress']['sort_key'] = '0';
         $this->fieldspec['emailaddress']['form_sort_key'] = '0';
         $this->fieldspec['emailaddress']['form_number'] = '1';
         $this->fieldspec['emailaddress']['default_value'] = ' ';
         $this->fieldspec['emailaddress']['field_toupper'] = 'NO';
         $this->fieldspec['emailaddress']['validationprocname'] = ' ';
         $this->fieldspec['emailaddress']['c_size'] = '255';
         $this->fieldspec['emailaddress']['prikey'] = 'N';
         $this->fieldspec['emailaddress']['noedit'] = 'N';
         $this->fieldspec['emailaddress']['nodisplay'] = 'N';
         $this->fieldspec['emailaddress']['c_unsigned'] = 'N';
         $this->fieldspec['emailaddress']['c_zerofill'] = 'N';
         $this->fieldspec['emailaddress']['c_auto_increment'] = 'N';
         $this->fieldspec['emailaddress']['foreign_table'] = ' ';
         $this->fieldspec['emailaddress']['foreign_key'] = ' ';
         $this->fieldspec['emailaddress']['application'] = 'investing';
         $this->fieldspec['emailaddress']['issearchable'] = '1';
         $this->fieldspec['firstname']['metadata_id'] = '2502';
         $this->fieldspec['firstname']['table_name'] = 'users';
         $this->fieldspec['firstname']['column_name'] = 'firstname';
         $this->fieldspec['firstname']['pretty_name'] = 'Firstname';
         $this->fieldspec['firstname']['abstract_data_type'] = 'string';
         $this->fieldspec['firstname']['db_data_type'] = 'varchar';
         $this->fieldspec['firstname']['field_null'] = 'NO';
         $this->fieldspec['firstname']['field_key'] = '0';
         $this->fieldspec['firstname']['extra_sql'] = ' ';
         $this->fieldspec['firstname']['html_form_type'] = 'char';
         $this->fieldspec['firstname']['html_form_options'] = ' ';
         $this->fieldspec['firstname']['html_form_explanation'] = ' ';
         $this->fieldspec['firstname']['help_text'] = ' ';
         $this->fieldspec['firstname']['mandatory_p'] = 'n';
         $this->fieldspec['firstname']['sort_key'] = '0';
         $this->fieldspec['firstname']['form_sort_key'] = '0';
         $this->fieldspec['firstname']['form_number'] = '1';
         $this->fieldspec['firstname']['default_value'] = ' ';
         $this->fieldspec['firstname']['field_toupper'] = 'NO';
         $this->fieldspec['firstname']['validationprocname'] = ' ';
         $this->fieldspec['firstname']['c_size'] = '45';
         $this->fieldspec['firstname']['prikey'] = 'n';
         $this->fieldspec['firstname']['noedit'] = 'n';
         $this->fieldspec['firstname']['nodisplay'] = 'n';
         $this->fieldspec['firstname']['c_unsigned'] = 'n';
         $this->fieldspec['firstname']['c_zerofill'] = 'n';
         $this->fieldspec['firstname']['c_auto_increment'] = 'n';
         $this->fieldspec['firstname']['foreign_table'] = ' ';
         $this->fieldspec['firstname']['foreign_key'] = ' ';
         $this->fieldspec['firstname']['application'] = 'investing';
         $this->fieldspec['firstname']['issearchable'] = '1';
         $this->fieldspec['password']['metadata_id'] = '2504';
         $this->fieldspec['password']['table_name'] = 'users';
         $this->fieldspec['password']['column_name'] = 'password';
         $this->fieldspec['password']['pretty_name'] = 'Password';
         $this->fieldspec['password']['abstract_data_type'] = 'password';
         $this->fieldspec['password']['db_data_type'] = 'varchar';
         $this->fieldspec['password']['field_null'] = 'NO';
         $this->fieldspec['password']['field_key'] = '0';
         $this->fieldspec['password']['extra_sql'] = ' ';
         $this->fieldspec['password']['html_form_type'] = 'password';
         $this->fieldspec['password']['html_form_options'] = ' ';
         $this->fieldspec['password']['html_form_explanation'] = ' ';
         $this->fieldspec['password']['help_text'] = ' ';
         $this->fieldspec['password']['mandatory_p'] = 'Y';
         $this->fieldspec['password']['sort_key'] = '0';
         $this->fieldspec['password']['form_sort_key'] = '0';
         $this->fieldspec['password']['form_number'] = '1';
         $this->fieldspec['password']['default_value'] = ' ';
         $this->fieldspec['password']['field_toupper'] = 'NO';
         $this->fieldspec['password']['validationprocname'] = ' ';
         $this->fieldspec['password']['c_size'] = '45';
         $this->fieldspec['password']['prikey'] = 'N';
         $this->fieldspec['password']['noedit'] = 'N';
         $this->fieldspec['password']['nodisplay'] = 'N';
         $this->fieldspec['password']['c_unsigned'] = 'N';
         $this->fieldspec['password']['c_zerofill'] = 'N';
         $this->fieldspec['password']['c_auto_increment'] = 'N';
         $this->fieldspec['password']['foreign_table'] = ' ';
         $this->fieldspec['password']['foreign_key'] = ' ';
         $this->fieldspec['password']['application'] = 'investing';
         $this->fieldspec['password']['issearchable'] = '1';
         $this->fieldspec['rolenumber']['metadata_id'] = '2532';
         $this->fieldspec['rolenumber']['table_name'] = 'users';
         $this->fieldspec['rolenumber']['column_name'] = 'rolenumber';
         $this->fieldspec['rolenumber']['pretty_name'] = 'Role Access Control';
         $this->fieldspec['rolenumber']['abstract_data_type'] = 'Integer Bit Flags';
         $this->fieldspec['rolenumber']['db_data_type'] = 'integer';
         $this->fieldspec['rolenumber']['field_null'] = 'NO';
         $this->fieldspec['rolenumber']['field_key'] = '0';
         $this->fieldspec['rolenumber']['extra_sql'] = ' ';
         $this->fieldspec['rolenumber']['html_form_type'] = 'fddl';
         $this->fieldspec['rolenumber']['html_form_options'] = '<fk><field>rolenumberdesc</field></fk>';
         $this->fieldspec['rolenumber']['html_form_explanation'] = ' ';
         $this->fieldspec['rolenumber']['help_text'] = 'Bit representation of access';
         $this->fieldspec['rolenumber']['mandatory_p'] = 'Y';
         $this->fieldspec['rolenumber']['sort_key'] = '0';
         $this->fieldspec['rolenumber']['form_sort_key'] = '0';
         $this->fieldspec['rolenumber']['form_number'] = '1';
         $this->fieldspec['rolenumber']['default_value'] = ' ';
         $this->fieldspec['rolenumber']['field_toupper'] = 'NO';
         $this->fieldspec['rolenumber']['validationprocname'] = ' ';
         $this->fieldspec['rolenumber']['c_size'] = '8';
         $this->fieldspec['rolenumber']['prikey'] = 'N';
         $this->fieldspec['rolenumber']['noedit'] = 'N';
         $this->fieldspec['rolenumber']['nodisplay'] = 'N';
         $this->fieldspec['rolenumber']['c_unsigned'] = 'N';
         $this->fieldspec['rolenumber']['c_zerofill'] = 'N';
         $this->fieldspec['rolenumber']['c_auto_increment'] = 'N';
         $this->fieldspec['rolenumber']['foreign_table'] = 'rolenumbers';
         $this->fieldspec['rolenumber']['foreign_key'] = 'rolenumbernumber';
         $this->fieldspec['rolenumber']['application'] = 'investing';
         $this->fieldspec['rolenumber']['issearchable'] = '1';
         $this->fieldspec['surname']['metadata_id'] = '2501';
         $this->fieldspec['surname']['table_name'] = 'users';
         $this->fieldspec['surname']['column_name'] = 'surname';
         $this->fieldspec['surname']['pretty_name'] = 'Surname';
         $this->fieldspec['surname']['abstract_data_type'] = 'string';
         $this->fieldspec['surname']['db_data_type'] = 'varchar';
         $this->fieldspec['surname']['field_null'] = 'NO';
         $this->fieldspec['surname']['field_key'] = '0';
         $this->fieldspec['surname']['extra_sql'] = ' ';
         $this->fieldspec['surname']['html_form_type'] = 'char';
         $this->fieldspec['surname']['html_form_options'] = ' ';
         $this->fieldspec['surname']['html_form_explanation'] = ' ';
         $this->fieldspec['surname']['help_text'] = ' ';
         $this->fieldspec['surname']['mandatory_p'] = 'n';
         $this->fieldspec['surname']['sort_key'] = '0';
         $this->fieldspec['surname']['form_sort_key'] = '0';
         $this->fieldspec['surname']['form_number'] = '1';
         $this->fieldspec['surname']['default_value'] = ' ';
         $this->fieldspec['surname']['field_toupper'] = 'NO';
         $this->fieldspec['surname']['validationprocname'] = ' ';
         $this->fieldspec['surname']['c_size'] = '45';
         $this->fieldspec['surname']['prikey'] = 'n';
         $this->fieldspec['surname']['noedit'] = 'n';
         $this->fieldspec['surname']['nodisplay'] = 'n';
         $this->fieldspec['surname']['c_unsigned'] = 'n';
         $this->fieldspec['surname']['c_zerofill'] = 'n';
         $this->fieldspec['surname']['c_auto_increment'] = 'n';
         $this->fieldspec['surname']['foreign_table'] = ' ';
         $this->fieldspec['surname']['foreign_key'] = ' ';
         $this->fieldspec['surname']['application'] = 'investing';
         $this->fieldspec['surname']['issearchable'] = '1';
         $this->fieldspec['username']['metadata_id'] = '2500';
         $this->fieldspec['username']['table_name'] = 'users';
         $this->fieldspec['username']['column_name'] = 'username';
         $this->fieldspec['username']['pretty_name'] = 'UserName';
         $this->fieldspec['username']['abstract_data_type'] = 'string';
         $this->fieldspec['username']['db_data_type'] = 'varchar';
         $this->fieldspec['username']['field_null'] = 'NO';
         $this->fieldspec['username']['field_key'] = '0';
         $this->fieldspec['username']['extra_sql'] = ' ';
         $this->fieldspec['username']['html_form_type'] = 'char';
         $this->fieldspec['username']['html_form_options'] = ' ';
         $this->fieldspec['username']['html_form_explanation'] = ' ';
         $this->fieldspec['username']['help_text'] = ' ';
         $this->fieldspec['username']['mandatory_p'] = 'y';
         $this->fieldspec['username']['sort_key'] = '0';
         $this->fieldspec['username']['form_sort_key'] = '0';
         $this->fieldspec['username']['form_number'] = '1';
         $this->fieldspec['username']['default_value'] = ' ';
         $this->fieldspec['username']['field_toupper'] = 'NO';
         $this->fieldspec['username']['validationprocname'] = ' ';
         $this->fieldspec['username']['c_size'] = '255';
         $this->fieldspec['username']['prikey'] = 'y';
         $this->fieldspec['username']['noedit'] = 'n';
         $this->fieldspec['username']['nodisplay'] = 'n';
         $this->fieldspec['username']['c_unsigned'] = 'n';
         $this->fieldspec['username']['c_zerofill'] = 'n';
         $this->fieldspec['username']['c_auto_increment'] = 'n';
         $this->fieldspec['username']['foreign_table'] = ' ';
         $this->fieldspec['username']['foreign_key'] = ' ';
         $this->fieldspec['username']['application'] = 'investing';
         $this->fieldspec['username']['issearchable'] = '1';
         $this->fieldlist = array('emailaddress', 'firstname', 'password', 'rolenumber', 'surname', 'username');
	         return SUCCESS;
         }
         function users()
         { //For older php which doesn't have constructor
         return $this->__constructor();
         }
         function Push()
         {
	         $_SESSION['users'] = serialize($this);
	         return SUCCESS;
         }
         function Pop()
         {
                 //Can't do this in self - this is how to do it outside
	       //  $this = unserialize($_SESSION['users']);
	         return SUCCESS;
         }
         function Setusername($value)
         {
                  $this->fieldspec['username']['VALUE'] = $value;
	          return SUCCESS;
         }
         function Getusername()
         {
                    return $this->fieldspec['username']['VALUE'];
         }
         function Validateusername()
         {
         }
} /* class users */
