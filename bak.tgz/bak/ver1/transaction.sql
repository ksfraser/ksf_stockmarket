---
--- Table struct for table transaction
---
DROP TABLE IF EXISTS `transaction`;
CREATE TABLE `transaction` (
`dollar` float(45)   NOT NULL  default ' ' comment 'Dollars',
`number` integer(8)   NOT NULL  default '0' comment 'Number',
`sequence` integer(8)   NOT NULL  default ' ' comment 'Sequence',
`stocksymbol` varchar(45)   NOT NULL  default ' ' comment 'Stock',
`transactiontype` varchar(45)   NOT NULL  default ' ' comment 'Transaction Type',
`user` varchar(45)   NOT NULL  default ' ' comment 'User'
PRIMARY KEY ('sequence')
) ENGINE=myIsam DEFAULT CHARSET=latin1;
