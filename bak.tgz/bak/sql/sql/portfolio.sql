DROP TABLE IF EXISTS `portfolio`;
CREATE TABLE `portfolio` (
`symbol` varchar(45)   NOT NULL  default '' comment 'Stock',
`number` integer(45)   NOT NULL  default '' comment 'Number',
`user` string(45)   NOT NULL  default '' comment 'User',
`cost` float(8)   NOT NULL  default '0.00' comment 'cost per stock', PRIMARY KEY (``)) ENGINE=InnoDB;
