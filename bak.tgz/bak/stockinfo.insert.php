<?php
require_once('stockinfo.class.php');
require_once('local.php');
$table = new stockinfo();
$mode = "insert";
require_once('controller/controller.php');
?>
