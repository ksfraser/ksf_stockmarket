<?php
require_once('portfolio.class.php');
require_once('local.php');
$table = new portfolio();
$mode = "delete";
require_once('controller/controller.php');
?>
