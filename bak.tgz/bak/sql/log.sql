---
--- Table struct for table log
---
DROP TABLE IF EXISTS `log`;
CREATE TABLE `log` (
`date` datetime(16)   NOT NULL  default ' ' comment 'date',
`query` varchar(2550)   NOT NULL  default ' ' comment 'query',
`user` varchar(45)   NOT NULL  default ' ' comment 'user',
`log_id` int(8)   NOT NULL auto_increment default ' ' comment 'row'
PRIMARY KEY ('log_id')
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
