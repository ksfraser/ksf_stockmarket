<?php
require_once('tenets.class.php');
require_once('local.php');
$table = new tenets();
$mode = "delete";
require_once('class.genericpage.php');
?>
