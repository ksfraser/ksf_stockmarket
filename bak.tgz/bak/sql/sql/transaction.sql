DROP TABLE IF EXISTS `transaction`;
CREATE TABLE `transaction` (
`sequence` integer(8)   NOT NULL  default '' comment 'Sequence',
`user` varchar(45)   NOT NULL  default '' comment 'User',
`stocksymbol` varchar(45)   NOT NULL  default '' comment 'Stock',
`number` integer(8)   NOT NULL  default '0' comment 'Number',
`transactiontype` varchar(45)   NOT NULL  default '' comment 'Transaction Type',
`dollar` float(45)   NOT NULL  default '' comment 'Dollars', PRIMARY KEY (`sequence`)) ENGINE=InnoDB;
