<?php
require_once('transaction.class.php');
require_once('local.php');
$table = new transaction();
$mode = "update";
require_once('controller/controller.php');
?>
