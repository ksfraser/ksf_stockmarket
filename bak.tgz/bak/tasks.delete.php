<?php
require_once('tasks.class.php');
require_once('local.php');
$table = new tasks();
$mode = "delete";
require_once('controller/controller.php');
?>
