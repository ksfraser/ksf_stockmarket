<?php
require_once('roletask.class.php');
require_once('local.php');
$table = new roletask();
$mode = "replace";
require_once('class.genericpage.php');
?>
