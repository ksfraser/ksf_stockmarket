---
--- Table struct for table transactiontype
---
DROP TABLE IF EXISTS `transactiontype`;
CREATE TABLE `transactiontype` (
`transactiontype` varchar(45)   NOT NULL  default ' ' comment 'Transaction Type'
PRIMARY KEY (``)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
