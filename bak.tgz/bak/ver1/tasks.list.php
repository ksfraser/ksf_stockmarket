<?php
require_once('tasks.class.php');
require_once('local.php');
$table = new tasks();
$mode = "list";
require_once('class.genericpage.php');
?>
