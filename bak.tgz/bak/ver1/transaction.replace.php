<?php
require_once('transaction.class.php');
require_once('local.php');
$table = new transaction();
$mode = "replace";
require_once('class.genericpage.php');
?>
