<?php
require_once('users.class.php');
require_once('local.php');
$table = new users();
$mode = "update";
require_once('controller/controller.php');
?>
