<?php
	//Class file for generic state machine actions

define(DONE, 99999);
	
class statemachine
{
	//A statemachine starts in the start state, is triggered by an event,
	//performs an action (optional) and transitions to another state.
	//This is repeated until the end state is reached.
	var $currentstate;
	var $nextstate;
	//If the trigger is auto, we move to the nextstate as soon as we are done performing the action
	//currentstate => nextstate
	var $state = array ();
	//currentstate => action
	var $action = array();
	//currentstate => trigger
	//Assuming triggers are unique
	var $trigger = array();
	//currentstate => description
	var $description = array();
	
	function statemachine()
	{
		return;
	}
	function __constructor()
	{
		return $this->statemachine();
	}
	function state_move()
	{
		$this->currentstate = $this->nextstate;
		return;
	}
	function state_end()
	{
		return DONE;
	}
	function findtrigger($currenttrigger)
	{
		//return the current state based upon trigger
		foreach ($this->trigger as $current => $trigger)
		{
			if ($trigger == $currenttrigger)
			{
				return $current;
			}
		}
		return NULL;
	}
	function findaction()
	{
		//Return the action to do
		foreach ($this->action as $current => $action)
		{
			if ($current == $this->currentstate)
			{
				return $action;
			}
		}
		return NULL;
	}
	function trigger_auto()
	{
		return $this->state_move();
	}
	function state_set_start()
	{
		foreach ($this->state as $current => $next)
		{
			if ($current == "start")
			{
				$this->currentstate = $current;
				$this->nextstate = $next;
			}
		}
		return;
	}
}
		
