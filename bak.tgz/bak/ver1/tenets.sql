---
--- Table struct for table tenets
---
DROP TABLE IF EXISTS `tenets`;
CREATE TABLE `tenets` (
`candid` integer(45)   NOT NULL  default ' ' comment 'Candid with Shareholders',
`consistent` integer(45)   NOT NULL  default ' ' comment 'Consistent Performance',
`discounted` integer(45)   NOT NULL  default ' ' comment 'Purchase at Discount',
`focusroe` integer(45)   NOT NULL  default ' ' comment 'Focus on Return on Equity, not EPS',
`highprofitmargin` integer(45)   NOT NULL  default ' ' comment 'High Profit Margins',
`longterm` integer(45)   NOT NULL  default ' ' comment 'Long Term Prospects',
`ownerearnings` integer(45)   NOT NULL  default ' ' comment 'Calculated Owner Earnings',
`rationalmanager` integer(45)   NOT NULL  default ' ' comment 'Rational Management',
`resistinstitution` integer(45)   NOT NULL  default ' ' comment 'Management resists the Institution',
`retainedtomarket` integer(45)   NOT NULL  default ' ' comment 'Retained Earnings become Market Value',
`simple` integer(45)   NOT NULL  default ' ' comment 'Simple Business',
`symbol` char(4)   NOT NULL  default 'ABCD' comment 'Company',
`valueofbusiness` integer(45)   NOT NULL  default ' ' comment 'Value of Business'
PRIMARY KEY ('symbol')
) ENGINE=myIsam DEFAULT CHARSET=latin1;
