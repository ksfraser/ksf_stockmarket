DROP TABLE IF EXISTS `stockinfo`;
CREATE TABLE `stockinfo` (
`stocksymbol` char(4)   NOT NULL  default '' comment 'Stock Symbol',
`exchange` varchar(255)   NOT NULL  default '' comment 'Stock Exchange',
`corporatename` varchar(255)   NOT NULL  default '' comment 'Corporate Name',
`averagevolume` integer(8)   NOT NULL  default '' comment 'Average Volume',
`52high` float(8)   NOT NULL  default '' comment '52 Week High',
`asofdate` datetime(12)   NOT NULL  default '' comment 'Last Update Date',
`52low` float(8)   NOT NULL  default '' comment '52 Week Low',
`EPS` double(8)   NOT NULL  default '' comment 'Earnings Per Share',
`low` float(8)   NOT NULL  default '' comment 'Low',
`high` float(8)   NOT NULL  default '' comment 'High', PRIMARY KEY (``)) ENGINE=InnoDB;
