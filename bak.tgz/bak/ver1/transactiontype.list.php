<?php
require_once('transactiontype.class.php');
require_once('local.php');
$table = new transactiontype();
$mode = "list";
require_once('class.genericpage.php');
?>
