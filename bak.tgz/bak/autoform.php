<?php

class autoform
{
	var $form;
	var $getform;
	var $tablefields;
	var $tableproperties;
	var $query;
	var $getresultsarray;
	function CreateForm()
	{
		if (count($_POST) > 0)
		{
			echo "IS Set POST";
		  $this->InsertData();
		}
		$cr_table = new Table();
		$cr_table->SetBorder(1);
		//Build the table from each item in the list
		foreach ($this->tablefields as $cr_fields => $a_values)
		{
			list($typelow, $size, $dbkftype, $listpos, $validation, $prikey, $caption, $touppercase, $null, $key, $default, $extra) = array_values($a_values);
			$type = strtoupper($typelow);
			switch ($type)
			{
			case 'TEXT':
			  $item = new Entry($caption, 'TEXT', $cr_fields, $size, $size);
			break;  
			case 'INT':
			case 'INTEGER':
			  $item = new Entry($caption, 'integer', $cr_fields, $size, $size);
			break;  
			case 'FDDL':
				$dbkf = Local_DB();
				$table = $extra['foreigntable'];
				$query = "select * from $table";
				$dbkf->SetQuery($query);
				$dbkf->Query();
				$item = $dbkf->ResultToDDL($extra['DDLvalue'], $extra['DDLdescription']); 
				$item->SetDisplayText($caption);
				$item->SetName($cr_fields);
				//$dbkf->enddbkf();
			break;
				

			}
			$cr_table->SetEntry($item);
		}
		$this->form->SetTable($cr_table);
	return ($cr_table);
	}
	function BuildInsertQuery()
	{
		$desttable = $this->tableproperties['tablename'];
	$this->query = "INSERT INTO $desttable (" . implode(", ",array_keys($_POST)) . ") VALUES ('" . implode("', '",array_values($_POST)) . "')";
	echo $this->query;
	}
	function InsertQuery()
	{
	  $dbkf = Local_DB();
	  $dbkf->SetQuery($this->query);
	  $dbkf->Query();
	  $dbkf->enddbkf();
	}
	function ValidateData()
	{
	}
	function InsertData()
	{
		$this->ValidateData();
		//If the validation passes
		$this->ProveTable();
		$this->BuildInsertQuery();
		$this->InsertQuery();
	}
	function GetData()
	{
		$keys = array_keys($_GET);
		$values = array_values($_GET);
	  $tablename = $this->tableproperties['tablename'];
	  $dbkf = Local_DB();
	  $dbkf->SetQuery("select * from $tablename");
 	  $dbkf->Query();
//	  var_dump($this->getresultsarray);
	  $table = $dbkf->ResultToTable($this->getresultsarray);
	  $table->SetBorder(1);
	  //$table->Display();
	  $returnval = $table->ReturnDisplay();
	  //$dbkf->enddbkf();
	  return $returnval;
	  
	}
	function ProveTable()
	{
	  $tablename = $this->tableproperties['tablename'];
	  $dbkf = Local_DB();
	  $dbkf->SetQuery("select * from $tablename");
 	  $dbkf->Query();
	  $dbkf->enddbkf();
	  echo "DB Error: $dbkf->error<br />";
	  if ($dbkf->error != NULL)
	  {
	    $this->CreateTable();
	  }
	}
	function CreateTable()
	{
  	  echo "CREATETABLE<br />";
	  $tablename = $this->tableproperties['tablename'];
	  $CreateQueryTable = "create table if not exists $tablename (";
	  $CreateQueryTableEnd = ")";
	  $CreateQueryColMany = "";
	  $QColCount = 0;

	  //Column Definition
	  $ColCount = count($this->tablefields);
	  echo "Count: $ColCount<br />";
	  foreach ($this->tablefields as $cr_fields => $a_values)
	  {
	      list($typelow, $size, $dbkftype, $listpos, $validation, $prikey, $caption, $touppercase, $null, $key, $default) = array_values($a_values);
	    $Col_Name = $cr_fields;
	    $Col_Type = my_type2CreateColType($dbkftype, $size);
	    echo "Name $Col_Name Type $Col_Type<br />";

	    if ($null == 'YES')
	    {
	      $Col_Null = 'NULL';
	    }
	    else
	    {
	      $Col_Null = 'NOT NULL';
	    }
	    if ($default != "")
	    {
	      $Col_Default = "DEFAULT '" . $default . "'";
	    }
	    else
	    {
		$Col_Default = "";
	    }	
	    $Col_Auto = '';
	    if ($prikey == 1)
	    {
	    	$Col_Key = 'PRIMARY KEY AUTO_INCREMENT';
	    }
	    else if (($key == 1) && ($prikey == 0))
	    {
	    	$Col_Key = '';
	    }
	    else
	    {
	    	$Col_Key = '';
	    }
	    $Col_Comment = "COMMENT '" . $caption . "'";
	  $CreateQueryCol = $Col_Name . ' ' . $Col_Type . ' ' . $Col_Null . ' ' . $Col_Default . ' ' . $Col_Auto . ' ' . $Col_Key . ' ' . $Col_Comment;
	  if ($Col_Type != "")
	  {
		  if ($QColCount == 0)
		  {
			  $CreateQueryColMany = $CreateQueryCol;
			  $QColCount = 1;
		  }
		  else
		  {
	    	    $CreateQueryColMany = $CreateQueryColMany . ',' . $CreateQueryCol;
		  }
	  }
	  } //Foreach
	  $CreateQuery = $CreateQueryTable . $CreateQueryColMany . $CreateQueryTableEnd;
	echo "$CreateQuery";
	$dbkf = Local_DB();
	$dbkf->SetQuery($CreateQuery);
 	$dbkf->Query();
	$dbkf->enddbkf();

	}
	function CreateGetForm()
	{
		$cr_table = new Table();
		$cr_table->SetBorder(1);
		//Build the table from each item in the list
		foreach ($this->tablefields as $cr_fields => $a_values)
		{
			list($typelow, $size, $dbkftype, $listpos, $validation, $prikey, $caption, $touppercase, $null, $key, $default, $extra) = array_values($a_values);
			$type = strtoupper($typelow);
			switch ($type)
			{
			case 'TEXT':
			  $item = new Entry($caption, 'TEXT', $cr_fields, $size, $size);
			break;  
			case 'INT':
			case 'INTEGER':
			  $item = new Entry($caption, 'integer', $cr_fields, $size, $size);
			break;  
			case 'FDDL':
				$dbkf = Local_DB();
				$table = $extra['foreigntable'];
				$query = "select * from $table";
				$dbkf->SetQuery($query);
				$dbkf->Query();
				$item = $dbkf->ResultToDDL($extra['DDLvalue'], $extra['DDLdescription']); 
				$item->SetDisplayText($caption);
				//$dbkf->enddb();
			break;
			}
			$cr_table->SetEntry($item);
		}
		$this->getform->SetTable($cr_table);
	}
	
}

?>