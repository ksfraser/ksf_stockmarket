<?php
require_once('tenets.class.php');
require_once('local.php');
$table = new tenets();
$mode = "insert";
require_once('controller/controller.php');
?>
