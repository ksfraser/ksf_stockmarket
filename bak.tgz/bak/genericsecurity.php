<?php
//This module will hold security "aspects" trying to use some of the concepts of AOP.


/*Common security issues to cover:
	CSS
	SQL Injection (covered in db.php query fcn.
	session hijacking
	session fixation (covered in security constructor below)
	session XXX
	session YYY
	Not filtering user data
		similar to sql injection - passing commands in 
		  input that the program doesn't clean
	Authentication gaps
	global variables - GET/POST variables become global, so checking for
		"if ($auth)" can be spooefed with ?auth=1
		This can be prevented by initiailizing your variable, but us 
		  lazy programmers don't always do that.
	error reporting - send bad data, see what errors 
	  are reported back.  Sort of like social engineering.
		

*/


class security
{
	var $menu = array();
	function security()
	{
		if (!isset($_SERVER['PHP_AUTH_USER'])) {
   			header('WWW-Authenticate: Basic realm="$realm"');
   			header('HTTP/1.0 401 Unauthorized');
   			echo 'Text to send if user hits Cancel button';
   			exit;
		} else {
			session_start();
			$old_session = $_SESSION;
			$my_sessid = $this->GenerateRandomString();
			session_destroy();
			//If you don't copy the $_SESSION array, you won't be able to use the data associated with the old session id.
			$RESULT = session_id($my_sessid);
			session_start();
			$_SESSION = $old_session;
			//Need to check the authentication here.  Check for usercode and pw out of the user table.
			//If the user doesn't exist, give warning.
		       //Check config (local.php?) to see if we should let 
		       //them reenter using the header directives above or 
		       //redirect to registration page.
			
			//var_dump($_SESSION);
			if (!isset($_SESSION['username']))
			{
				$this->login2cookie($_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW']);
			}
			//if (!NOSMARTY)
			//{
				global $smarty;
				$this->AddMenu($smarty);
			//}
			return $RESULT;
		}
	}
	function AddMenu($smarty)
	{
		//Dynamically add to menu based upon user access
		include_once('local.php');
		$query = "select t.tasktype, t.taskdescription, t.tasklink from tasks t join roletask on t.idtasks = roletask.idtasks join users on users.rolenumber = roletask.rolenumber where users.username = '" . $_SERVER['PHP_AUTH_USER'] . "'";
		$db = Local_DB();
		$db->SetQuery($query);
		$db->Query();
		$db->ResultToRows();
		//var_dump($db->rows);
		$smarty->assign('securemenu', $db->resultrows);
	}
	function login2cookie($username, $password)
	{
		$_SESSION['username'] = $username;
		$_SESSION['password'] = sha1($password);
	}
	function ChangeAccessLevel()
	{
		//To prevent session fixation, we need to do this.
		if (!isset($_SESSION['initiated']))	
		{
    			session_regenerate_id();
    			$_SESSION['initiated'] = true;
		}
	}
	function GenerateRandomString()
	{
   		$randlen = 32;
   		$randval = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
   		$random = "";
   		for ($i = 1; $i <= $randlen; $i++) {
       			$random .= substr($randval, rand(0,(strlen($randval) - 1)), 1);
   		}
   		return $random;
	}		
	function ValidateFormFields()
	{
		//The following lines are an example of how to do this.
		switch ($_POST['form'])
		{
    			case 'login':
        			$allowed = array();
        			$allowed[] = 'form';
        			$allowed[] = 'username';
        			$allowed[] = 'password';
		        	$sent = array_keys($_POST);
				//This checks to see if the sent fields are identical and in the same order as the allowed array.
       				if ($allowed == $sent)
        			{
            				include '/inc/logic/process.inc';
        			}
		        break;
		}
	}
	function ValidateEnumData()
	{
		//This example checks that a named field is set to a set of data or ignores the data.
		$clean = array();
		switch ($_POST['color'])
		{
    			case 'red':
    			case 'green':
    			case 'blue':
        			$clean['color'] = $_POST['color'];
        		break;
		}
		return $clean;
	}

} //End of class



if (!isset($NOHTTPS))
{
	//Force the use of HTTPS
//	header('location:https://' . $_SERVER['SERVER_NAME'] . $_SERVER['PHP_SELF']);
}

//Using include rather than include_once because we want to prevent others from being able to inject into our code.
include('smarty/libs/Smarty.class.php');
$smarty = new Smarty();
$Security = new security();
?>
