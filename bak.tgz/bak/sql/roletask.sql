---
--- Table struct for table roletask
---
DROP TABLE IF EXISTS `roletask`;
CREATE TABLE `roletask` (
`idroletask` integer(8)   NOT NULL  default '0' comment 'Index',
`rolenumber` integer(8)   NOT NULL  default ' ' comment 'Role',
`idtasks` integer(8)   NOT NULL  default ' ' comment 'Task'
PRIMARY KEY (`idroletask`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
