<?php
	define( "SUCCESS", "1" );
	define( "FAILURE", "2" );

	class generictable 
	{
		var $querytablename;
		var $querystring;
		var $resultarray;
		var $resultxml;
		var $select = NULL;
		var $from = NULL;
		var $where = NULL;
		var $groupby = NULL;
		var $having = NULL;
		var $orderby = NULL;
		var $limit = NULL;
		var $server;
		var $user;
		var $pass;
		var $uniquekeys;
		var $relationship;
		var $errors;
		var $unformatted_data; //Array of key/value pairs that has been addslashed/adjusted for int sizes.
		var $primary_key = array();
		var $unique_keys = array();
		var $child_relations = array();
		var $parent_relations = array();
		var $requestedpagenumber; //what page the user wants to see - used in limit
		var $rowsperpage; //Display option, but used to limit selections
		var $lastpage; //Calculated - number of rows total div rowsperpage
		var $fieldlist; //List of fields
		var $fieldspec; //metadata about the fields
		
		function __constructor()
		{
			//SHould build the primary_key array here.
			return SUCCESS;
		}

		function SelectQuery()
		{
			if (empty($this->select))
			{
				$selectstring = '*';
			} else {
				$selectstring = $this->select;
			}
			if (empty($this->from))
			{
				$fromstring = $this->querytablename;
			} else {
				$fromstring = $this->from;
			}
			if (empty($this->where))
			{
				$wherestring = NULL;
			} else {
				$wherestring = "WHERE $this->where";
			}
			if (empty($this->groupby))
			{
				$groupbystring = NULL;
			} else {
				$groupbystring = "GROUP BY $this->groupby";
			}
			if (empty($this->having))
			{
				$havingstring = NULL;
			} else {
				$havingstring = "HAVING $this->having";
			}
			if (empty($this->orderby))
			{
				$orderbystring = NULL;
			} else {
				$orderbystring = "ORDER BY $this->orderby";
			}
			if (empty($this->limit))
			{
				$limitstring = NULL;
			} else {
				$limitstring = "LIMIT $this->limit";
			}
		
			
			$this->querystring = "SELECT $selectstring FROM $fromstring $wherestring $groupbystring $havingstring $orderbystring $limitstring";
			//echo $this->querystring ;
			return SUCCESS;
		}
		function DeleteQuery()
		{
			//delete from table where value=""
			$query = "delete from $this->querytablename ";
			$count = 1;
			$wherestring = "";
			//var_dump($this->unformatted_data);
			foreach ($this->unformatted_data as $key => $value )
			{
				if ($count > 1)
				{
					$wherestring .= " AND ";
				}
				$wherestring .= "$key='$value'";
				$count = $count + 1;
			}
			$this->querystring = "$query where $wherestring;";
			//echo $this->query;
		}
		function UpdateQuery()
		{
			//update table set value="" where value=""
			$query = "update $this->querytablename set ";
			$valuestring = "";
			$wherestring = "";
			$count = 1;
			foreach ($this->unformatted_data as $key => $value )
			{
				//If it is a primary key, it should be in the where
				//else it should be in the update
				if ($this->fieldspec[$key]['prikey'] == "Y")
				{
					if ($count > 1)
					{
						$wherestring .= " AND ";
					}
					$wherestring .= "$key='$value'";
					$count = $count + 1;
				}
				else
				{
					$valuestring .= " $key='$value',";
				}
			}
			$wherestring = rtrim( $wherestring, "," );
			$valuestring = rtrim( $valuestring, "," );
			$this->querystring = "$query $valuestring where $wherestring;";
			//echo $this->querystring;
		}
		function InsertQuery()
		{
			$this->querystring = "INSERT INTO $this->querytablename (" . implode(", ",array_keys($this->unformatted_data)) . ") VALUES ('" . implode("', '",array_values($this->unformatted_data)) . "')";
			echo $this->querystring;
			return SUCCESS;
		}
		function GenericQuery()
		{
			require_once('local.php');
			$db = Local_DB();
			$db->SetQuery($this->querystring);
			$res = $db->Query();
			$array = array();
			if ($db->result != NULL)
			{
				while ($row = @mysql_fetch_assoc($db->result))
				{
					$array[] = $row;
				}
			}
			//mysql_free_result($res);
			$this->resultarray = $array;
			$this->Array2XML();
			return $array;
		}
		function Array2XML($set = "RECORDSET", $record = "RECORD")
		{
			//
			$resultarray = $this->resultarray;
			$xmlstring = '<?xml version="1.0" encoding="UTF-8"?>\n';
			$xmlstring .= "<" . $set . ">\n";
			foreach ($resultarray as $key => $array)
			{
				$xmlstring .= "<" . $record . ">\n";
				foreach ($array as $key => $value)
				{
					$xmlstring .= '<key="' . $key . '">' . $value . '</key>\n';
				}
				$xmlstring .= "</" . $record . ">\n";
			}
			$xmlstring .= "</" . $set . ">\n";
			$this->resultxml = $xmlstring;
			return $xmlstring;
		}
		function InsertFieldValidation($fieldarray)
		{
			$this->errors = array();
			$this->unformatted_data = array();

			//Only insert fields listed in fieldspec, which is generated from the db.
			//var_dump($fieldarray); //Most likely $_POST
		/*	
			foreach ($fieldarray as $key => $value)
			{
				$this->unformatted_data[$key] = $value;
			}
		*/	//var_dump($this->unformatted_data);
		
			
			foreach ($this->fieldspec as $field => $spec) 
			{
				if (isset($fieldarray[$field]))
				{
					$value = $fieldarray[$field];
				} else {
					$value = NULL;
				}
				$value = $this->FieldValidation($field, $value, $spec);
				if (strlen($value) > 0) 
				{
					$this->unformatted_data[$field] = $value;
				}
			}
			
			return SUCCESS;
		}
		function UpdateFieldValidation($fieldarray)
		{
			
			$this->errors = array();
			$this->unformatted_data = array();
			//echo "<h1>Input Array</h1>";
			//var_dump($fieldarray);
			//echo "<h2>List of fields in the table</h2>";
			//var_dump($this->fieldlist);
			//echo "<h3>Check for existance of key in table!!</h3>";
			//var_dump(array_intersect_key($fieldarray, $this->fieldlist));
			foreach ($fieldarray as $field => $value)
			{
				//echo "<br />F: ::$field:: V: ::$value::<br />";
				//Check that the field is in the table
				
				if (!in_array($field, $this->fieldlist))
				{
					//echo "Field $field empty<br />";
					
				//	return FAILURE;
				}
				else
				{
					//echo "Key in list<br />";
					$spec = $this->fieldspec[$field];
					$value = $this->FieldValidation($field, $value, $spec);
					//echo "Returned valeu: ::$value::";
					if (strlen($value) > 0) 
					{
						$this->unformatted_data[$field] = $value;
					} else {
						$this->unformatted_data[$field] = NULL;
					}
				}
			}
			//var_dump($this->unformatted_data);
			return SUCCESS;
		}
		function FieldValidation($field, $value, $spec)
		{
			$field = trim($field);
			//ENUM
			/*if ($spec['type'] == 'enum')
			{
				$enum = $this->getValRep($field);
				$value = $enum[$value];
			}
			*/
			//BOOL
			/*if (is_True($value))
			{
				$value = $spec['true'];
			}
			else
			{
				$value = $spec['false'];
			}
			*/
			if (strlen($value) == 0)
			{
				if (strtoupper($spec['mandatory_p']) == 'Y')
				{
					$this->errors[$field] = "$field can't be blank";
				}
				//Set date to end of time - makes calcs easier
				/*
				if ($spec['type'] == 'date')
				{
					$value = '9999-12-31';
				}
				*/
			} else {
				if (strtoupper($spec['field_toupper']) == 'Y')
				{
					$value = strtoupper($value);
				}
				if (strtoupper($spec['abstract_data_type']) == 'STRING' OR strtoupper($spec['abstract_data_type']) == 'TEXT')
				{
					$value = addslashes($value);
				}
				if (strtoupper($spec['abstract_data_type']) == 'INTEGER' OR strtoupper($spec['abstract_data_type']) == 'INT' OR strtoupper($spec['abstract_data_type']) == 'NUMBER')
				{
					$value = $this->ValidateInteger($field, $value, $spec);
				}
			}
			return $value;
		}
		function ValidateInteger($field, $value, $spec)
		{
			$pattern = '(int1|tinyint|int2|smallint|int3|mediumint|int4|integer|int8|bigint|int)';
   			if (preg_match($pattern, strtolower($spec['db_data_type']), $match)) 
			{
				// test that input contains a valid value for an integer field
      				$integer = (int)$value;
      				if ((string)$value <> (string)$integer) 
				{
         				$this->errors[$field] = "Value is not an integer";
         				return NULL;
      				} // if
      				// set min/max values depending of size of field
      				switch ($match[0])
				{	
					case 'int1':
         				case 'tinyint': 
            					$minvalue = -128;
            					$maxvalue =  127;
            					break;
         				case 'int2':
         				case 'smallint': 
            					$minvalue = -32768;
            					$maxvalue =  32767;
            					break;
         				case 'int3';
         				case 'mediumint':
            					$minvalue = -8388608;
            					$maxvalue =  8388607;
            					break;
         				case 'int':
         				case 'int4':
         				case 'integer':
            					$minvalue = -2147483648;
            					$maxvalue =  2147483647;
            					break;
         				case 'int8':
         				case 'bigint':
            					$minvalue = -9223372036854775808;
            					$maxvalue =  9223372036854775807;
            					break;
         				default: 
            					$this->errors[$field] = "Unknown integer type ($match)";
            					return $value;
      				} // switch
      
      				// adjust min/max values if integer is unsigned
      				if ($spec['c_unsigned']) 
				{
         				$minvalue = 0;
         				$maxvalue = ($maxvalue * 2) +1;
      				} // if
      				if (isset($spec['minvalue'])) 	
				{
         				// override with value provided in $fieldspec
         				$minvalue = (int)$spec['minvalue'];
      				} // if
      				if ($integer < $minvalue) 
				{
         				$this->errors[$field] = "Value is below minimum value ($minvalue)";
					$value = $minvalue;
      				} // if
      				if (isset($spec['maxvalue'])) 
				{
         				// override with value provided in $fieldspec
         				$maxvalue = (int)$spec['maxvalue'];
      				} // if
      				if ($integer > $maxvalue) 
				{
         				$this->errors[$field] = "Value is above maximum value ($maxvalue)";
					$value = $maxvalue;
      				} // if
            			if (isset($spec['zerofill'])) {
         				while (strlen($value) < $spec['size'])
					{
            					$value = '0' .$value;
					} // while
				} // if   
			} // if
   
   		return $value;
		}
		function Insert($data)
		{
			//Data will come in a POST?
			if (SUCCESS == $this->InsertFieldValidation($data))
			{	//build unformatted_data
				if (SUCCESS == $this->InsertQuery())
				{	 //Build the Insert query string
					$this->GenericQuery(); //Query db
				}
				return SUCCESS; //Bold assumption
			}
			else
			{
				return FAILURE;
			}
		}
		function Update()
		{
			//Data will come in a POST?
			$status = $this->UpdateFieldValidation($_POST); //build unformatted_data
			if ($status == SUCCESS)
			{
				$this->UpdateQuery(); //Build the Update query string
				$this->GenericQuery(); //Query db
			}
			return SUCCESS; //Bold assumption
		}
		function Select()
		{
			$this->SelectQuery();
			//echo "Query: $this->querystring\n";
			$resultarray = $this->GenericQuery();
			return $resultarray;
		}
		function _Delete($data)
		{
			//Data will come in a POST/GET?
			//var_dump($data);
			$status = $this->UpdateFieldValidation($data); //build unformatted_data
			if ($status == SUCCESS)
			{
				$this->DeleteQuery(); //Build the Update query string
				$this->GenericQuery(); //Query db
			}
			else
			{
				return FAILURE;
			}
			return SUCCESS; //Bold assumption
		}
	}
