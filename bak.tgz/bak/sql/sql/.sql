DROP TABLE IF EXISTS ``;
CREATE TABLE `` (
`` ()   NOT NULL  default '' comment '', PRIMARY KEY (``)) ENGINE=InnoDB;
