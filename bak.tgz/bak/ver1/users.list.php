<?php
require_once('users.class.php');
require_once('local.php');
$table = new users();
$mode = "list";
require_once('class.genericpage.php');
?>
