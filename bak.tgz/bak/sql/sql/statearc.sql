DROP TABLE IF EXISTS `statearc`;
CREATE TABLE `statearc` (
`workflow_id` smallint(5) unsigned  NULL  default '' comment '',
`transition_id` smallint(5) unsigned  NULL  default '' comment '',
`place_id` smallint(5) unsigned  NULL  default '' comment '',
`direction` char(3)   NULL  default '' comment '',
`arc_type` varchar(10)   NULL  default '' comment '',
`pre_condition` text,
()   NOT NULL  default '' comment '',
`created_date` datetime()   NULL  default '' comment '',
`created_user` varchar(16)   NOT NULL  default '' comment '',
`revised_date` datetime()   NOT NULL  default '' comment '',
`revised_user` varchar(16)   NOT NULL  default '' comment '',
`workflow_id` smallint(5) unsigned  NULL  default '' comment '',
`transition_id` smallint(5) unsigned  NULL  default '' comment '',
`place_id` smallint(5) unsigned  NULL  default '' comment '',
`direction` char(3)   NULL  default '' comment '',
`arc_type` varchar(10)   NULL  default '' comment '',
`pre_condition` text,
()   NOT NULL  default '' comment '',
`created_date` datetime()   NULL  default '' comment '',
`created_user` varchar(16)   NOT NULL  default '' comment '',
`revised_date` datetime()   NOT NULL  default '' comment '',
`revised_user` varchar(16)   NOT NULL  default '' comment '',
`workflow_id` smallint(5) unsigned  NULL  default '' comment 'Workflow Process',
`transition_id` smallint(5) unsigned  NULL  default '' comment 'Transition that this Arc connects to',
`place_id` smallint(5) unsigned  NULL  default '' comment 'Place that this Arc connects to',
`direction` char(3)   NULL  default '' comment 'Direction of Arc (Into/Out of) Transition',
`arc_type` varchar(10)   NULL  default 'auto' comment 'Arc Type (auto or manual)',
`pre_condition` text()   NOT NULL  default 'none' comment 'Precondition',
`created_date` datetime()   NULL  default '' comment '',
`created_user` varchar(16)   NOT NULL  default '' comment '',
`revised_date` datetime()   NOT NULL  default '' comment '',
`revised_user` varchar(16)   NOT NULL  default '' comment '', PRIMARY KEY (`workflow_id`, 'workflow_id', 'transition_id', 'place_id', 'direction', 'workflow_id', 'transition_id', 'place_id', 'direction', 'workflow_id', 'transition_id', 'place_id')) ENGINE=InnoDB;
