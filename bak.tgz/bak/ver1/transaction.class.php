<?php 
//this script may only be included - so its better to die if called directly.
if (strpos($_SERVER["SCRIPT_NAME"],basename(__FILE__)) !== false) {
  header("location: index.php");
  exit;
}

require_once('class.generictable.php');
require_once('transaction.class.inc.php');
class transaction extends generictable{
         function __constructor()
         {
         $this->querytablename = 'transaction';
         $this->fieldspec['dollar']['metadata_id'] = '2514';
         $this->fieldspec['dollar']['table_name'] = 'transaction';
         $this->fieldspec['dollar']['column_name'] = 'dollar';
         $this->fieldspec['dollar']['pretty_name'] = 'Dollars';
         $this->fieldspec['dollar']['abstract_data_type'] = 'real';
         $this->fieldspec['dollar']['db_data_type'] = 'float';
         $this->fieldspec['dollar']['field_null'] = 'NO';
         $this->fieldspec['dollar']['field_key'] = '0';
         $this->fieldspec['dollar']['extra_sql'] = ' ';
         $this->fieldspec['dollar']['html_form_type'] = 'float';
         $this->fieldspec['dollar']['html_form_options'] = ' ';
         $this->fieldspec['dollar']['html_form_explanation'] = ' ';
         $this->fieldspec['dollar']['help_text'] = ' ';
         $this->fieldspec['dollar']['mandatory_p'] = 'Y';
         $this->fieldspec['dollar']['sort_key'] = '0';
         $this->fieldspec['dollar']['form_sort_key'] = '0';
         $this->fieldspec['dollar']['form_number'] = '1';
         $this->fieldspec['dollar']['default_value'] = ' ';
         $this->fieldspec['dollar']['field_toupper'] = 'NO';
         $this->fieldspec['dollar']['validationprocname'] = ' ';
         $this->fieldspec['dollar']['c_size'] = '45';
         $this->fieldspec['dollar']['prikey'] = 'N';
         $this->fieldspec['dollar']['noedit'] = 'N';
         $this->fieldspec['dollar']['nodisplay'] = 'N';
         $this->fieldspec['dollar']['c_unsigned'] = 'N';
         $this->fieldspec['dollar']['c_zerofill'] = 'N';
         $this->fieldspec['dollar']['c_auto_increment'] = 'N';
         $this->fieldspec['dollar']['foreign_table'] = ' ';
         $this->fieldspec['dollar']['foreign_key'] = ' ';
         $this->fieldspec['dollar']['application'] = 'investing';
         $this->fieldspec['dollar']['issearchable'] = '1';
         $this->fieldspec['number']['metadata_id'] = '2508';
         $this->fieldspec['number']['table_name'] = 'transaction';
         $this->fieldspec['number']['column_name'] = 'number';
         $this->fieldspec['number']['pretty_name'] = 'Number';
         $this->fieldspec['number']['abstract_data_type'] = 'integer';
         $this->fieldspec['number']['db_data_type'] = 'integer';
         $this->fieldspec['number']['field_null'] = 'NO';
         $this->fieldspec['number']['field_key'] = '0';
         $this->fieldspec['number']['extra_sql'] = ' ';
         $this->fieldspec['number']['html_form_type'] = 'int';
         $this->fieldspec['number']['html_form_options'] = ' ';
         $this->fieldspec['number']['html_form_explanation'] = ' ';
         $this->fieldspec['number']['help_text'] = ' ';
         $this->fieldspec['number']['mandatory_p'] = 'Y';
         $this->fieldspec['number']['sort_key'] = '0';
         $this->fieldspec['number']['form_sort_key'] = '0';
         $this->fieldspec['number']['form_number'] = '1';
         $this->fieldspec['number']['default_value'] = '0';
         $this->fieldspec['number']['field_toupper'] = 'NO';
         $this->fieldspec['number']['validationprocname'] = ' ';
         $this->fieldspec['number']['c_size'] = '8';
         $this->fieldspec['number']['prikey'] = 'N';
         $this->fieldspec['number']['noedit'] = 'N';
         $this->fieldspec['number']['nodisplay'] = 'N';
         $this->fieldspec['number']['c_unsigned'] = 'N';
         $this->fieldspec['number']['c_zerofill'] = 'N';
         $this->fieldspec['number']['c_auto_increment'] = 'N';
         $this->fieldspec['number']['foreign_table'] = ' ';
         $this->fieldspec['number']['foreign_key'] = ' ';
         $this->fieldspec['number']['application'] = 'investing';
         $this->fieldspec['number']['issearchable'] = '1';
         $this->fieldspec['sequence']['metadata_id'] = '2505';
         $this->fieldspec['sequence']['table_name'] = 'transaction';
         $this->fieldspec['sequence']['column_name'] = 'sequence';
         $this->fieldspec['sequence']['pretty_name'] = 'Sequence';
         $this->fieldspec['sequence']['abstract_data_type'] = 'integer';
         $this->fieldspec['sequence']['db_data_type'] = 'integer';
         $this->fieldspec['sequence']['field_null'] = 'NO';
         $this->fieldspec['sequence']['field_key'] = '0';
         $this->fieldspec['sequence']['extra_sql'] = ' ';
         $this->fieldspec['sequence']['html_form_type'] = 'int';
         $this->fieldspec['sequence']['html_form_options'] = ' ';
         $this->fieldspec['sequence']['html_form_explanation'] = ' ';
         $this->fieldspec['sequence']['help_text'] = ' ';
         $this->fieldspec['sequence']['mandatory_p'] = 'Y';
         $this->fieldspec['sequence']['sort_key'] = '0';
         $this->fieldspec['sequence']['form_sort_key'] = '0';
         $this->fieldspec['sequence']['form_number'] = '1';
         $this->fieldspec['sequence']['default_value'] = ' ';
         $this->fieldspec['sequence']['field_toupper'] = 'NO';
         $this->fieldspec['sequence']['validationprocname'] = ' ';
         $this->fieldspec['sequence']['c_size'] = '8';
         $this->fieldspec['sequence']['prikey'] = 'Y';
         $this->fieldspec['sequence']['noedit'] = 'N';
         $this->fieldspec['sequence']['nodisplay'] = 'N';
         $this->fieldspec['sequence']['c_unsigned'] = 'N';
         $this->fieldspec['sequence']['c_zerofill'] = 'N';
         $this->fieldspec['sequence']['c_auto_increment'] = 'N';
         $this->fieldspec['sequence']['foreign_table'] = ' ';
         $this->fieldspec['sequence']['foreign_key'] = ' ';
         $this->fieldspec['sequence']['application'] = 'investing';
         $this->fieldspec['sequence']['issearchable'] = '1';
         $this->fieldspec['stocksymbol']['metadata_id'] = '2507';
         $this->fieldspec['stocksymbol']['table_name'] = 'transaction';
         $this->fieldspec['stocksymbol']['column_name'] = 'stocksymbol';
         $this->fieldspec['stocksymbol']['pretty_name'] = 'Stock';
         $this->fieldspec['stocksymbol']['abstract_data_type'] = 'string';
         $this->fieldspec['stocksymbol']['db_data_type'] = 'varchar';
         $this->fieldspec['stocksymbol']['field_null'] = 'NO';
         $this->fieldspec['stocksymbol']['field_key'] = '0';
         $this->fieldspec['stocksymbol']['extra_sql'] = ' ';
         $this->fieldspec['stocksymbol']['html_form_type'] = 'fddl';
         $this->fieldspec['stocksymbol']['html_form_options'] = '<fk><field>corporatename</field></fk>';
         $this->fieldspec['stocksymbol']['html_form_explanation'] = ' ';
         $this->fieldspec['stocksymbol']['help_text'] = ' ';
         $this->fieldspec['stocksymbol']['mandatory_p'] = 'Y';
         $this->fieldspec['stocksymbol']['sort_key'] = '0';
         $this->fieldspec['stocksymbol']['form_sort_key'] = '0';
         $this->fieldspec['stocksymbol']['form_number'] = '1';
         $this->fieldspec['stocksymbol']['default_value'] = ' ';
         $this->fieldspec['stocksymbol']['field_toupper'] = 'NO';
         $this->fieldspec['stocksymbol']['validationprocname'] = ' ';
         $this->fieldspec['stocksymbol']['c_size'] = '45';
         $this->fieldspec['stocksymbol']['prikey'] = 'N';
         $this->fieldspec['stocksymbol']['noedit'] = 'N';
         $this->fieldspec['stocksymbol']['nodisplay'] = 'N';
         $this->fieldspec['stocksymbol']['c_unsigned'] = 'N';
         $this->fieldspec['stocksymbol']['c_zerofill'] = 'N';
         $this->fieldspec['stocksymbol']['c_auto_increment'] = 'N';
         $this->fieldspec['stocksymbol']['foreign_table'] = 'stockinfo';
         $this->fieldspec['stocksymbol']['foreign_key'] = 'stocksymbol';
         $this->fieldspec['stocksymbol']['application'] = 'investing';
         $this->fieldspec['stocksymbol']['issearchable'] = '1';
         $this->fieldspec['transactiontype']['metadata_id'] = '2509';
         $this->fieldspec['transactiontype']['table_name'] = 'transaction';
         $this->fieldspec['transactiontype']['column_name'] = 'transactiontype';
         $this->fieldspec['transactiontype']['pretty_name'] = 'Transaction Type';
         $this->fieldspec['transactiontype']['abstract_data_type'] = 'string';
         $this->fieldspec['transactiontype']['db_data_type'] = 'varchar';
         $this->fieldspec['transactiontype']['field_null'] = 'NO';
         $this->fieldspec['transactiontype']['field_key'] = '0';
         $this->fieldspec['transactiontype']['extra_sql'] = ' ';
         $this->fieldspec['transactiontype']['html_form_type'] = 'fddl';
         $this->fieldspec['transactiontype']['html_form_options'] = '<fk><field>transactiontype</field></fk>';
         $this->fieldspec['transactiontype']['html_form_explanation'] = ' ';
         $this->fieldspec['transactiontype']['help_text'] = ' ';
         $this->fieldspec['transactiontype']['mandatory_p'] = 'Y';
         $this->fieldspec['transactiontype']['sort_key'] = '0';
         $this->fieldspec['transactiontype']['form_sort_key'] = '0';
         $this->fieldspec['transactiontype']['form_number'] = '1';
         $this->fieldspec['transactiontype']['default_value'] = ' ';
         $this->fieldspec['transactiontype']['field_toupper'] = 'NO';
         $this->fieldspec['transactiontype']['validationprocname'] = ' ';
         $this->fieldspec['transactiontype']['c_size'] = '45';
         $this->fieldspec['transactiontype']['prikey'] = 'N';
         $this->fieldspec['transactiontype']['noedit'] = 'N';
         $this->fieldspec['transactiontype']['nodisplay'] = 'N';
         $this->fieldspec['transactiontype']['c_unsigned'] = 'N';
         $this->fieldspec['transactiontype']['c_zerofill'] = 'N';
         $this->fieldspec['transactiontype']['c_auto_increment'] = 'N';
         $this->fieldspec['transactiontype']['foreign_table'] = 'transactiontype';
         $this->fieldspec['transactiontype']['foreign_key'] = 'transactiontype';
         $this->fieldspec['transactiontype']['application'] = 'investing';
         $this->fieldspec['transactiontype']['issearchable'] = '1';
         $this->fieldspec['user']['metadata_id'] = '2506';
         $this->fieldspec['user']['table_name'] = 'transaction';
         $this->fieldspec['user']['column_name'] = 'user';
         $this->fieldspec['user']['pretty_name'] = 'User';
         $this->fieldspec['user']['abstract_data_type'] = 'string';
         $this->fieldspec['user']['db_data_type'] = 'varchar';
         $this->fieldspec['user']['field_null'] = 'NO';
         $this->fieldspec['user']['field_key'] = '0';
         $this->fieldspec['user']['extra_sql'] = ' ';
         $this->fieldspec['user']['html_form_type'] = 'fddl';
         $this->fieldspec['user']['html_form_options'] = '<fk><field>surname</field><field>firstname</field></fk>';
         $this->fieldspec['user']['html_form_explanation'] = ' ';
         $this->fieldspec['user']['help_text'] = ' ';
         $this->fieldspec['user']['mandatory_p'] = 'Y';
         $this->fieldspec['user']['sort_key'] = '0';
         $this->fieldspec['user']['form_sort_key'] = '0';
         $this->fieldspec['user']['form_number'] = '1';
         $this->fieldspec['user']['default_value'] = ' ';
         $this->fieldspec['user']['field_toupper'] = 'NO';
         $this->fieldspec['user']['validationprocname'] = ' ';
         $this->fieldspec['user']['c_size'] = '45';
         $this->fieldspec['user']['prikey'] = 'N';
         $this->fieldspec['user']['noedit'] = 'N';
         $this->fieldspec['user']['nodisplay'] = 'N';
         $this->fieldspec['user']['c_unsigned'] = 'N';
         $this->fieldspec['user']['c_zerofill'] = 'N';
         $this->fieldspec['user']['c_auto_increment'] = 'N';
         $this->fieldspec['user']['foreign_table'] = 'users';
         $this->fieldspec['user']['foreign_key'] = 'username';
         $this->fieldspec['user']['application'] = 'investing';
         $this->fieldspec['user']['issearchable'] = '1';
         $this->fieldlist = array('dollar', 'number', 'sequence', 'stocksymbol', 'transactiontype', 'user');
	         return SUCCESS;
         }
         function transaction()
         { //For older php which doesn't have constructor
         return $this->__constructor();
         }
         function Push()
         {
	         $_SESSION['transaction'] = serialize($this);
	         return SUCCESS;
         }
         function Pop()
         {
                 //Can't do this in self - this is how to do it outside
	       //  $this = unserialize($_SESSION['transaction']);
	         return SUCCESS;
         }
         function Setuser($value)
         {
                  $this->fieldspec['user']['VALUE'] = $value;
	          return SUCCESS;
         }
         function Getuser()
         {
                    return $this->fieldspec['user']['VALUE'];
         }
         function Validateuser()
         {
         }
} /* class transaction */
