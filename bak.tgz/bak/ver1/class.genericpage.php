<?php
	//Generic class for displaying pages
	//To Be Included by my code generator in the generated scripts


	//Remember that the check for nodisplay is disabled in array2table
	//This is because the query isn't setting the field for foreign key values.
	
define('NOSMARTY', 0);

	
class item
{
	var $item = array();
	function __constructor()
	{
		return SUCCESS;
	}
	function SetItem($item)
	{
		$this->item[] = $item;
		return SUCCESS;
	}
	function item()
	{
		return $this->__constructor();
	}
	function Display()
	{
		$ret = "";
		for ($i = 0; $i < count($this->item); $i++)
		{
			$ret .= $this->item[$i]->Display();
		}
		return $ret;
	}
}

class atomic
{
	var $item;
	var $starttag;
	var $endtag;
	function atomic($item = "", $starttag = "", $endtag = "")
	{
		$this->item = $item;
		$this->starttag = $starttag;
		$this->endtag = $endtag;
	}
	function Display()
	{
		if (NOSMARTY)
		{
			return $this->starttag . $this->item . $this->endtag;
		}
	}
}

class PageTitle extends atomic
{
	function PageTitle($title = "Please Set Me")
	{
		//$this->title = $title;
		if (NOSMARTY)
		{
			parent::atomic($title, "<title>", "</title>");
		}
		else
		{
			global $smarty;
			$smarty->assign('pagetitle', $title);
		}
	}
}


class PageHeader extends item
{
	var $header;
	function PageHeader($header = "Please Set Me")
	{
		if (NOSMARTY)
		{
			$this->header = $header;
		}
		else
		{
			global $smarty;
			$smarty->assign('header1', $header);
		}
	}
	function Display()
	{
		if (NOSMARTY)
		{
			return "<h1> $this->header </h1>";
		}
	}
}


class HeaderBlock extends item
{
	function HeaderBlock()
	{
		$this->__constructor();
	}
	function Display()
	{
		if (NOSMARTY)
		{
			$ret =  "<head>";
			$ret .= parent::Display();
			$ret .= "</head>";
			return $ret;
		}
	}
}

class genericpage extends item
{
	var $mode;
	function genericpage($titlestring = NULL, $header = NULL)
	{
		//Turn off error reporting
		error_reporting(0);
		$this->__constructor();
		if (NOSMARTY)
		{
			$headerblock = new HeaderBlock();
			$title = new PageTitle($titlestring);
			$headerblock->SetItem($title);
			$this->SetItem($headerblock);
			$sbody = new atomic("<body>");
			$this->SetItem($sbody);
			$header = new PageHeader($header);
			$this->SetItem($header);
		}
		else
		{
			global $smarty;
			$smarty->assign('pagetitle', $titlestring);
			$smarty->assign('header1', $header);
			$smarty->assign('user', $_SERVER['PHP_AUTH_USER']);
		}
		
	}
	function Display()
	{
		if (NOSMARTY)
		{
			$ret = "<html>";
			$ret .= parent::Display();
			echo $ret . "</html>";
		}
	}
		
//To add a new record
	function InsertForm($class = NULL, $data = NULL)
	{
		if (NULL == $class)
		{
			echo "class is NULL";
			return NULL;
		}
		require_once('form.php');
		require_once('entry.php');
		require_once('table.php');
		require_once('tablerows.php');
		global $smarty;
		$form = new Form($_SERVER['PHP_SELF'], "POST");
		$smarty->assign('insertformaction', $_SERVER['PHP_SELF']);
		$smarty->assign('insertformmethod', "POST");
		$table = new Table();
		$table->SetBorder(1);
		$smarty->assign('inserttableborder', "1");
		$form->SetEntry($table);
		$rowcount = 0;
			  			
		//Add hidden field of mode
		$hidden = new Entry($this->mode, 'HIDDEN', "mode", 0, 0, $this->mode);
		$tablerow[$rowcount]['caption'] = $this->mode;
		$tablerow[$rowcount]['inputtype'] = 'HIDDEN';
		$tablerow[$rowcount]['name'] = "mode";
		$tablerow[$rowcount]['size'] = 0;
		$tablerow[$rowcount]['maxlength'] = 0;
		$tablerow[$rowcount]['defaultvalue'] = $this->mode;
		$rowcount++;

		$columncount = count($class->fieldlist);
		for ($j = 0; $j < $columncount ; $j++)
		{
			$col = $class->fieldlist[$j];
			//echo "Counter: $j, Column: $col\n";
			//Any fields that aren't read only should be entered
			if (strtoupper($class->fieldspec[$col]['noedit']) == 'N')
			{
				//Get the html form type, etc
				$size = $class->fieldspec[$col]['c_size'];
				$caption = $class->fieldspec[$col]['pretty_name'];
				if (strlen(trim($caption)) < 1)
				{
					$caption = $col;
				}
				//echo "Caption: $caption, Size: $size, Type: " . strtoupper($class->fieldspec[$col]['html_form_type']) . "\n";
				$value = "";

				if ($this->mode == "insert")
				{
					$value = $class->fieldspec[$col]['default_value'];
				} else if (($this->mode == "update") OR ($this->mode == "replace"))
				{
					$value = $data[$col];
				}
				switch (strtoupper($class->fieldspec[$col]['html_form_type']))
				{
					case 'HIDDEN':
			  			$item = new Entry($caption, 'HIDDEN', $col, $size, $size, $value);
						$tablerow[$rowcount]['caption'] = $caption;
						$tablerow[$rowcount]['inputtype'] = 'HIDDEN';
						$tablerow[$rowcount]['name'] = $col;
						$tablerow[$rowcount]['size'] = $size;
						$tablerow[$rowcount]['maxlength'] = $size;
						$tablerow[$rowcount]['defaultvalue'] = $value;
						$rowcount++;
						
						break;  
					case 'TEXT':
					case 'CHAR':
			  			$item = new Entry($caption, 'TEXT', $col, $size, $size, $value);
						$tablerow[$rowcount]['caption'] = $caption;
						$tablerow[$rowcount]['inputtype'] = 'TEXT';
						$tablerow[$rowcount]['name'] = $col;
						$tablerow[$rowcount]['size'] = $size;
						$tablerow[$rowcount]['maxlength'] = $size;
						$tablerow[$rowcount]['defaultvalue'] = $value;
						$tablerow[$rowcount]['taborder'] = $class->fieldspec[$col]['form_sort_key'];
						$rowcount++;
						break;  
					case 'PASSWORD':
			  			$item = new Entry($caption, 'PASSWORD', $col, $size, $size, $value);
						$tablerow[$rowcount]['caption'] = $caption;
						$tablerow[$rowcount]['inputtype'] = 'PASSWORD';
						$tablerow[$rowcount]['name'] = $col;
						$tablerow[$rowcount]['size'] = $size;
						$tablerow[$rowcount]['maxlength'] = $size;
						$tablerow[$rowcount]['defaultvalue'] = $value;
						$tablerow[$rowcount]['taborder'] = $class->fieldspec[$col]['form_sort_key'];
						$rowcount++;
						break;  
					case 'INT':
					case 'INTEGER':
			  			$item = new Entry($caption, 'integer', $col, $size, $size, $value);
						$tablerow[$rowcount]['caption'] = $caption;
						$tablerow[$rowcount]['inputtype'] = 'INTEGER';
						$tablerow[$rowcount]['name'] = $col;
						$tablerow[$rowcount]['size'] = $size;
						$tablerow[$rowcount]['maxlength'] = $size;
						$tablerow[$rowcount]['defaultvalue'] = $value;
						$tablerow[$rowcount]['taborder'] = $class->fieldspec[$col]['form_sort_key'];
						$rowcount++;
						break;  
					case 'FLOAT':
			  			$item = new Entry($caption, 'TEXT', $col, $size, $size, $value);
						$tablerow[$rowcount]['caption'] = $caption;
						$tablerow[$rowcount]['inputtype'] = 'TEXT';
						$tablerow[$rowcount]['name'] = $col;
						$tablerow[$rowcount]['size'] = $size;
						$tablerow[$rowcount]['maxlength'] = $size;
						$tablerow[$rowcount]['defaultvalue'] = $value;
						$tablerow[$rowcount]['taborder'] = $class->fieldspec[$col]['form_sort_key'];
						$rowcount++;
						break;  
					case 'FDDL':
						//$class->fieldspec[$col]['extra_sql'];
						$dbkf = Local_DB();
						$q_table = $class->fieldspec[$col]['foreign_table'];
						$query = "select * from $q_table";
						$dbkf->SetQuery($query);
						$dbkf->Query();
						$xmlstring = "<?xml version='1.0' standalone='yes'?>" . $class->fieldspec[$col]['html_form_options'];
						$xml = new SimpleXMLElement($xmlstring);
						$description1 = (string) $xml->field[0];
						if (isset($xml->field[1]))
						{
							$description2 = (string) $xml->field[1];
						} else {
							$description2 = NULL;
						}
						$item = $dbkf->ResultToDDL($class->fieldspec[$col]['foreign_key'], $description1, $description2); 
						$item->SetDisplayText($caption);
						$item->SetName($col);
						//$dbkf->enddbkf();
					break;
				}
				$row = new TableRow();
				$row->SetEntry($item);
				$table->SetEntry($row);
			} //IF   
		}
		$row = new TableRow();
		$row->SetEntry($hidden);
		$table->SetEntry($row);
		$smarty->assign('insertformtable', $tablerow);
			
	return $form;
	}
	
	function Array2Table($class)
	{
		if (NOSMARTY)
		{
			require_once('table.php');
			$table = new Table();
			$table->SetBorder("1");
			$headerrow = new TableRow();
			$tablerow = new TableRow();
			$table->SetEntry($headerrow);
			$headercount = 0;
			foreach ($class->resultarray as $row)
			{
				$getstring = "&";
				$colcount = 0;
				foreach ($row as $col => $value)
				{
					//echo "$col<br />";
					if ($colcount == 0)
					{
						$getstring .= $col . "=" . $value;
						$colcount = 1;
					}
					else
					{
						$getstring .= "&" .$col . "=" . $value;
					}
					//if ($class->fieldspec[$col]['nodisplay'] == 'N')
					//{
						//OK to put into table
						//BODY
						$cell = new RowDataCell("1", "1", "CENTER", "CENTER", $value);
						$tablerow->AddCell($cell);
						//HEADER
						if ($headercount < 1)
						{
							if (isset($class->fieldspec[$col]['pretty_name']) AND (strlen($class->fieldspec[$col]['pretty_name']) > 0 AND $class->fieldspec[$col]['pretty_name'] != " "))
							{
								$headercell = new RowHeaderCell($class->fieldspec[$col]['pretty_name']);
							}
							else
							{
								$headercell = new RowHeaderCell($col);
							}
							$headerrow->AddCell($headercell);
						}
					//} //Implicit else
				}
				if (($this->mode == "update") OR ($this->mode== "list"))
				{
					$updatetext = new RowDataCell(NULL, NULL, NULL, NULL, '<a href="' . $class->querytablename . '.update.php?update=1' . $getstring . '">update</a>');
					$tablerow->AddCell($updatetext);
				}
				if (($this->mode == "delete") OR ($this->mode== "list"))
				{
					$deltext = new RowDataCell(NULL, NULL, NULL, NULL, '<a href="' . $class->querytablename . '.delete.php?delete=1' . $getstring . '">delete</a>');
					$tablerow->AddCell($deltext);
				}
	//			$updatetext->SetEntry('<a href="">update</a>');
	//			$deltext->SetEntry('<a href="">delete</a>');
					$headercount = $headercount + 1;
				//After each row, need to add a new one
			
			//	var_dump($headerrow);
				if ($headercount == 0)
				{
					/*
				if (($this->mode == "update") OR ($this->mode == "delete"))
				{
					*/
					$headercell = new RowHeaderCell("Action");
					//$headercell = new RowHeaderCell("Action");
					//$headerrow->AddCell($actheader);
					$headerrow->AddCell($headercell);
					/*
				}
				*/
				
					$table->SetEntry($headerrow);
					$headercount = $headercount + 1;
				}
				$table->SetEntry($tablerow);
				$tablerow = new TableRow();
			}
			return $table;
		}
		else
		{
			//SMARTY
			global $smarty;
			$smarty->assign($class->querytablename, $class->resultarray);
			$smarty->assign('dbtable', $class->querytablename);
			$smarty->assign('tablerows', count($class->resultarray));
				
		}
	}
	function PageAddTable($table)
	{
			//If there are foreign keys, retrieve them as well
		/*
		extra_sql contains helper sql to set sections
		OR we could figure out the fields, stuff manually from FDDL and html_form_options
		*/

		$count = 0;
		//Only select the fields you are going to display
		$dispcount = 0;
		foreach ($table->fieldlist as $coldisplay)
		{
			if (strcasecmp($table->fieldspec[$coldisplay]['nodisplay'], "Y") != 0)
			{
				//OK to display
				if ($dispcount == 0)
				{
					$table->select = $table->querytablename . "." . $coldisplay;
					$dispcount++;
				} else {
					$table->select .= ", " . $table->querytablename . "." . $coldisplay;
					$dispcount++;
				}
			}
		}
		$table->from = $table->querytablename;
		$table->where = "";
		
		foreach ($table->fieldlist as $col)
		{
			//if foreign key
			if (strlen($table->fieldspec[$col]['foreign_key']) > 1)
			{
				//Add the fk table.key into the select statement

 				//as long as it isn't already in the select (unique/alias sql error)
				
                                if (isset($this->fk[$table->fieldspec[$col]['foreign_table']][$table->fieldspec[$col]['foreign_key']]));
                                {
                                        $this->fk[$table->fieldspec[$col]['foreign_table']][$table->fieldspec[$col]['foreign_key']] = 1;
                                        continue;
                                }
                                $this->fk[$table->fieldspec[$col]['foreign_table']][$table->fieldspec[$col]['foreign_key']] = 1;
				
				$table->select .= ", " . $table->fieldspec[$col]['foreign_table'] . "." . $table->fieldspec[$col]['foreign_key'];
				//Snag fk info out of xml field
				$xmlstring = "<?xml version='1.0' standalone='yes'?>";
			        $xmlstring .= $table->fieldspec[$col]['html_form_options'];
				$xml = new SimpleXMLElement($xmlstring);
				//If there is more than 1 "field" in the xml, we want to concat the data from the 
				//foreign table to be resolved for this key
				$table->select .= ", " ;
				$fk = "concat(" ;

				$count2 = 0;
				foreach ($xml->field as $colresolve)
				{
					if ($count2 < 1)
					{
						$fk .= $table->fieldspec[$col]['foreign_table'] . "." . (string)$colresolve;
						$count2++;
					}
					else
					{
						//$table->select .= ", ', '," . $table->fieldspec[$col]['foreign_table'] . "." . (string)$colresolve;
						$fk .= ", ', '," . $table->fieldspec[$col]['foreign_table'] . "." . (string)$colresolve;
					}
					
					$table->fieldspec[(string)$colresolve]['nodisplay'] = 'N';
					$table->fieldlist[] = (string)$colresolve;
				

					//These will add onto the display list
					//$table->fieldspec[$fk]['nodisplay'] = 'N';
					//$table->fieldspec[(string)$colresolve]['nodisplay'] = 'N';
					//$table->fieldlist[] = (string)$colresolve;				
				}
				$fk .= ")";
				$table->select .= $fk;
				//End of concatting the fields together
				//If you are going to select from a foreign table, it has to be in the FROM
				$table->from .= ", " . $table->fieldspec[$col]['foreign_table'];
				
				//To add the foreign key into the results to be displayed
				$table->fieldspec[$fk]['nodisplay'] = 'N';
				$table->fieldspec[$fk]['pretty_name'] = (string)$xml->pretty_name;
				$table->fieldlist[] = $fk;
				if ($count < 1)
				{
					$table->where .= $table->querytablename . "." . $col . "=" . $table->fieldspec[$col]['foreign_table'] . "." . $table->fieldspec[$col]['foreign_key'];
					$count++;
				}
				else
				{
					$table->where .= " AND ";
				$table->where .= $table->querytablename . "." . $col . "=" . $table->fieldspec[$col]['foreign_table'] . "." . $table->fieldspec[$col]['foreign_key'];
				}
				
			}
		}
		$table->Select();
		$this->SetItem($this->Array2Table($table));
	}
}


//MAIN PART - called by being included in another script.

//function PageMain()
//{
	error_reporting(E_ALL);
	//error_log('syslog');
	require_once('genericsecurity.php');
	global $Security;
	if (!NOSMARTY)
	{
		global $smarty;
		$smarty->assign('callingpage', $table->querytablename);
		//$Security->AddMenu($smarty);
	}
	$menu = new atomic();
	$page = new genericpage();
	$page->SetItem($menu);
	if (isset($mode))
	{
		$page->mode = $mode;
	} else if (isset($_GET['mode']))
	{
		$page->mode = $_GET['mode'];
	}
	if (count($_POST) > 1)
	{
		if ($_POST['mode'] == "insert")
		{
		//var_dump($_POST);
			$status = $table->Insert($_POST);
			if ($status == SUCCESS)
			{
				echo "SUCESS<br />";
			} else
			{
				echo "Failure<br />";
			}
		} else if ($_POST['mode'] == "update")
		{
		//var_dump($_POST);
			$table->Update($_POST);
		} else if ($_POST['mode'] == "replace")
		{
		//var_dump($_POST);
			$table->Update($_POST);
		} else if ($_POST['mode'] == "delete")
		{
		//var_dump($_POST);
			$table->_Delete($_POST);
		} 
	}
	if ((isset($_GET['update'])) OR (isset($_GET['replace'])))
	{
		//
		$table->Update($_GET);	
		$page->SetItem($page->InsertForm($table, $_GET));
	}
	if (isset($_GET['delete']))
	{
		// var_dump($_GET);
		$table->_Delete($_GET);	
		header("Location: " . $_SERVER['PHP_SELF']);
	}
	
	if ($mode == "insert")
	{
		$page->SetItem($page->InsertForm($table));
	}
	else
	if ($mode == "list")
	{
		$page->PageAddTable($table);
	}
	else
	if ($mode == "replace")
	{
		$page->PageAddTable($table);
	}
	else
	if ($mode == "update")
	{
		$page->PageAddTable($table);
	}
	else
	if ($mode == "delete")
	{
		$page->PageAddTable($table);
	}
	if (!NOSMARTY)
	{
		$smarty->assign('legacy', $page->Display() );
		$smarty->display('genericpage.tpl'); 
	} else
	{
		$page->Display();
	}
	return;
	
//}

	
?>

			
