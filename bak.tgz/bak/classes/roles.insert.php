<?php
require_once('roles.class.php');
require_once('local.php');
$table = new roles();
$mode = "insert";
require_once('controller/controller.php');
?>
