<?php
require_once('transactiontype.class.php');
require_once('local.php');
$table = new transactiontype();
$mode = "update";
require_once('controller/controller.php');
?>
