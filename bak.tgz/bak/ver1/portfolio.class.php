<?php 
//this script may only be included - so its better to die if called directly.
if (strpos($_SERVER["SCRIPT_NAME"],basename(__FILE__)) !== false) {
  header("location: index.php");
  exit;
}

require_once('class.generictable.php');
require_once('portfolio.class.inc.php');
class portfolio extends generictable{
         function __constructor()
         {
         $this->querytablename = 'portfolio';
         $this->fieldspec['number']['metadata_id'] = '2512';
         $this->fieldspec['number']['table_name'] = 'portfolio';
         $this->fieldspec['number']['column_name'] = 'number';
         $this->fieldspec['number']['pretty_name'] = 'Number';
         $this->fieldspec['number']['abstract_data_type'] = 'integer';
         $this->fieldspec['number']['db_data_type'] = 'integer';
         $this->fieldspec['number']['field_null'] = 'NO';
         $this->fieldspec['number']['field_key'] = '0';
         $this->fieldspec['number']['extra_sql'] = ' ';
         $this->fieldspec['number']['html_form_type'] = 'int';
         $this->fieldspec['number']['html_form_options'] = ' ';
         $this->fieldspec['number']['html_form_explanation'] = ' ';
         $this->fieldspec['number']['help_text'] = ' ';
         $this->fieldspec['number']['mandatory_p'] = 'Y';
         $this->fieldspec['number']['sort_key'] = '0';
         $this->fieldspec['number']['form_sort_key'] = '0';
         $this->fieldspec['number']['form_number'] = '1';
         $this->fieldspec['number']['default_value'] = ' ';
         $this->fieldspec['number']['field_toupper'] = 'NO';
         $this->fieldspec['number']['validationprocname'] = ' ';
         $this->fieldspec['number']['c_size'] = '45';
         $this->fieldspec['number']['prikey'] = 'N';
         $this->fieldspec['number']['noedit'] = 'N';
         $this->fieldspec['number']['nodisplay'] = 'N';
         $this->fieldspec['number']['c_unsigned'] = 'N';
         $this->fieldspec['number']['c_zerofill'] = 'N';
         $this->fieldspec['number']['c_auto_increment'] = 'N';
         $this->fieldspec['number']['foreign_table'] = ' ';
         $this->fieldspec['number']['foreign_key'] = ' ';
         $this->fieldspec['number']['application'] = 'investing';
         $this->fieldspec['number']['issearchable'] = '1';
         $this->fieldspec['symbol']['metadata_id'] = '2511';
         $this->fieldspec['symbol']['table_name'] = 'portfolio';
         $this->fieldspec['symbol']['column_name'] = 'symbol';
         $this->fieldspec['symbol']['pretty_name'] = 'Stock';
         $this->fieldspec['symbol']['abstract_data_type'] = 'string';
         $this->fieldspec['symbol']['db_data_type'] = 'varchar';
         $this->fieldspec['symbol']['field_null'] = 'NO';
         $this->fieldspec['symbol']['field_key'] = '0';
         $this->fieldspec['symbol']['extra_sql'] = ' ';
         $this->fieldspec['symbol']['html_form_type'] = 'char';
         $this->fieldspec['symbol']['html_form_options'] = ' ';
         $this->fieldspec['symbol']['html_form_explanation'] = ' ';
         $this->fieldspec['symbol']['help_text'] = ' ';
         $this->fieldspec['symbol']['mandatory_p'] = 'Y';
         $this->fieldspec['symbol']['sort_key'] = '0';
         $this->fieldspec['symbol']['form_sort_key'] = '0';
         $this->fieldspec['symbol']['form_number'] = '1';
         $this->fieldspec['symbol']['default_value'] = ' ';
         $this->fieldspec['symbol']['field_toupper'] = 'NO';
         $this->fieldspec['symbol']['validationprocname'] = ' ';
         $this->fieldspec['symbol']['c_size'] = '45';
         $this->fieldspec['symbol']['prikey'] = 'N';
         $this->fieldspec['symbol']['noedit'] = 'N';
         $this->fieldspec['symbol']['nodisplay'] = 'N';
         $this->fieldspec['symbol']['c_unsigned'] = 'N';
         $this->fieldspec['symbol']['c_zerofill'] = 'N';
         $this->fieldspec['symbol']['c_auto_increment'] = 'N';
         $this->fieldspec['symbol']['foreign_table'] = ' ';
         $this->fieldspec['symbol']['foreign_key'] = ' ';
         $this->fieldspec['symbol']['application'] = 'investing';
         $this->fieldspec['symbol']['issearchable'] = '1';
         $this->fieldspec['user']['metadata_id'] = '2513';
         $this->fieldspec['user']['table_name'] = 'portfolio';
         $this->fieldspec['user']['column_name'] = 'user';
         $this->fieldspec['user']['pretty_name'] = 'User';
         $this->fieldspec['user']['abstract_data_type'] = 'string';
         $this->fieldspec['user']['db_data_type'] = 'string';
         $this->fieldspec['user']['field_null'] = 'NO';
         $this->fieldspec['user']['field_key'] = '0';
         $this->fieldspec['user']['extra_sql'] = ' ';
         $this->fieldspec['user']['html_form_type'] = 'fddl';
         $this->fieldspec['user']['html_form_options'] = '<fk><field>username</field></fk>';
         $this->fieldspec['user']['html_form_explanation'] = ' ';
         $this->fieldspec['user']['help_text'] = ' ';
         $this->fieldspec['user']['mandatory_p'] = 'Y';
         $this->fieldspec['user']['sort_key'] = '0';
         $this->fieldspec['user']['form_sort_key'] = '0';
         $this->fieldspec['user']['form_number'] = '1';
         $this->fieldspec['user']['default_value'] = ' ';
         $this->fieldspec['user']['field_toupper'] = 'NO';
         $this->fieldspec['user']['validationprocname'] = ' ';
         $this->fieldspec['user']['c_size'] = '45';
         $this->fieldspec['user']['prikey'] = 'N';
         $this->fieldspec['user']['noedit'] = 'N';
         $this->fieldspec['user']['nodisplay'] = 'N';
         $this->fieldspec['user']['c_unsigned'] = 'N';
         $this->fieldspec['user']['c_zerofill'] = 'N';
         $this->fieldspec['user']['c_auto_increment'] = 'N';
         $this->fieldspec['user']['foreign_table'] = ' ';
         $this->fieldspec['user']['foreign_key'] = ' ';
         $this->fieldspec['user']['application'] = 'investing';
         $this->fieldspec['user']['issearchable'] = '1';
         $this->fieldlist = array('number', 'symbol', 'user');
	         return SUCCESS;
         }
         function portfolio()
         { //For older php which doesn't have constructor
         return $this->__constructor();
         }
         function Push()
         {
	         $_SESSION['portfolio'] = serialize($this);
	         return SUCCESS;
         }
         function Pop()
         {
                 //Can't do this in self - this is how to do it outside
	       //  $this = unserialize($_SESSION['portfolio']);
	         return SUCCESS;
         }
         function Setuser($value)
         {
                  $this->fieldspec['user']['VALUE'] = $value;
	          return SUCCESS;
         }
         function Getuser()
         {
                    return $this->fieldspec['user']['VALUE'];
         }
         function Validateuser()
         {
         }
} /* class portfolio */
