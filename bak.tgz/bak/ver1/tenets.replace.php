<?php
require_once('tenets.class.php');
require_once('local.php');
$table = new tenets();
$mode = "replace";
require_once('class.genericpage.php');
?>
