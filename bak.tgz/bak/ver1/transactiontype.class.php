<?php 
//this script may only be included - so its better to die if called directly.
if (strpos($_SERVER["SCRIPT_NAME"],basename(__FILE__)) !== false) {
  header("location: index.php");
  exit;
}

require_once('class.generictable.php');
require_once('transactiontype.class.inc.php');
class transactiontype extends generictable{
         function __constructor()
         {
         $this->querytablename = 'transactiontype';
         $this->fieldspec['transactiontype']['metadata_id'] = '2510';
         $this->fieldspec['transactiontype']['table_name'] = 'transactiontype';
         $this->fieldspec['transactiontype']['column_name'] = 'transactiontype';
         $this->fieldspec['transactiontype']['pretty_name'] = 'Transaction Type';
         $this->fieldspec['transactiontype']['abstract_data_type'] = 'string';
         $this->fieldspec['transactiontype']['db_data_type'] = 'varchar';
         $this->fieldspec['transactiontype']['field_null'] = 'NO';
         $this->fieldspec['transactiontype']['field_key'] = '0';
         $this->fieldspec['transactiontype']['extra_sql'] = ' ';
         $this->fieldspec['transactiontype']['html_form_type'] = 'char';
         $this->fieldspec['transactiontype']['html_form_options'] = ' ';
         $this->fieldspec['transactiontype']['html_form_explanation'] = ' ';
         $this->fieldspec['transactiontype']['help_text'] = ' ';
         $this->fieldspec['transactiontype']['mandatory_p'] = 'Y';
         $this->fieldspec['transactiontype']['sort_key'] = '0';
         $this->fieldspec['transactiontype']['form_sort_key'] = '0';
         $this->fieldspec['transactiontype']['form_number'] = '1';
         $this->fieldspec['transactiontype']['default_value'] = ' ';
         $this->fieldspec['transactiontype']['field_toupper'] = 'YES';
         $this->fieldspec['transactiontype']['validationprocname'] = ' ';
         $this->fieldspec['transactiontype']['c_size'] = '45';
         $this->fieldspec['transactiontype']['prikey'] = 'N';
         $this->fieldspec['transactiontype']['noedit'] = 'N';
         $this->fieldspec['transactiontype']['nodisplay'] = 'N';
         $this->fieldspec['transactiontype']['c_unsigned'] = 'N';
         $this->fieldspec['transactiontype']['c_zerofill'] = 'N';
         $this->fieldspec['transactiontype']['c_auto_increment'] = 'N';
         $this->fieldspec['transactiontype']['foreign_table'] = ' ';
         $this->fieldspec['transactiontype']['foreign_key'] = ' ';
         $this->fieldspec['transactiontype']['application'] = 'investing';
         $this->fieldspec['transactiontype']['issearchable'] = '1';
         $this->fieldlist = array('transactiontype');
	         return SUCCESS;
         }
         function transactiontype()
         { //For older php which doesn't have constructor
         return $this->__constructor();
         }
         function Push()
         {
	         $_SESSION['transactiontype'] = serialize($this);
	         return SUCCESS;
         }
         function Pop()
         {
                 //Can't do this in self - this is how to do it outside
	       //  $this = unserialize($_SESSION['transactiontype']);
	         return SUCCESS;
         }
         function Settransactiontype($value)
         {
                  $this->fieldspec['transactiontype']['VALUE'] = $value;
	          return SUCCESS;
         }
         function Gettransactiontype()
         {
                    return $this->fieldspec['transactiontype']['VALUE'];
         }
         function Validatetransactiontype()
         {
         }
} /* class transactiontype */
