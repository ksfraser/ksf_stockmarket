---
--- Table struct for table portfolio
---
DROP TABLE IF EXISTS `portfolio`;
CREATE TABLE `portfolio` (
`number` integer(45)   NOT NULL  default ' ' comment 'Number',
`symbol` varchar(45)   NOT NULL  default ' ' comment 'Stock',
`user` string(45)   NOT NULL  default ' ' comment 'User'
PRIMARY KEY ('')
) ENGINE=myIsam DEFAULT CHARSET=latin1;
