<?php 
//this script may only be included - so its better to die if called directly.
if (strpos($_SERVER["SCRIPT_NAME"],basename(__FILE__)) !== false) {
  header("location: index.php");
  exit;
}

require_once('class.generictable.php');
require_once('roletask.class.inc.php');
class roletask extends generictable{
         function __constructor()
         {
         $this->querytablename = 'roletask';
         $this->fieldspec['idroletask']['metadata_id'] = '2538';
         $this->fieldspec['idroletask']['table_name'] = 'roletask';
         $this->fieldspec['idroletask']['column_name'] = 'idroletask';
         $this->fieldspec['idroletask']['pretty_name'] = 'Index';
         $this->fieldspec['idroletask']['abstract_data_type'] = 'index';
         $this->fieldspec['idroletask']['db_data_type'] = 'integer';
         $this->fieldspec['idroletask']['field_null'] = 'NO';
         $this->fieldspec['idroletask']['field_key'] = '0';
         $this->fieldspec['idroletask']['extra_sql'] = ' ';
         $this->fieldspec['idroletask']['html_form_type'] = 'hidden';
         $this->fieldspec['idroletask']['html_form_options'] = ' ';
         $this->fieldspec['idroletask']['html_form_explanation'] = ' ';
         $this->fieldspec['idroletask']['help_text'] = ' ';
         $this->fieldspec['idroletask']['mandatory_p'] = 'Y';
         $this->fieldspec['idroletask']['sort_key'] = '0';
         $this->fieldspec['idroletask']['form_sort_key'] = '0';
         $this->fieldspec['idroletask']['form_number'] = '1';
         $this->fieldspec['idroletask']['default_value'] = '0';
         $this->fieldspec['idroletask']['field_toupper'] = 'NO';
         $this->fieldspec['idroletask']['validationprocname'] = ' ';
         $this->fieldspec['idroletask']['c_size'] = '8';
         $this->fieldspec['idroletask']['prikey'] = 'Y';
         $this->fieldspec['idroletask']['noedit'] = 'N';
         $this->fieldspec['idroletask']['nodisplay'] = 'N';
         $this->fieldspec['idroletask']['c_unsigned'] = 'N';
         $this->fieldspec['idroletask']['c_zerofill'] = 'N';
         $this->fieldspec['idroletask']['c_auto_increment'] = 'N';
         $this->fieldspec['idroletask']['foreign_table'] = ' ';
         $this->fieldspec['idroletask']['foreign_key'] = ' ';
         $this->fieldspec['idroletask']['application'] = 'investing';
         $this->fieldspec['idroletask']['issearchable'] = '1';
         $this->fieldspec['idtasks']['metadata_id'] = '2540';
         $this->fieldspec['idtasks']['table_name'] = 'roletask';
         $this->fieldspec['idtasks']['column_name'] = 'idtasks';
         $this->fieldspec['idtasks']['pretty_name'] = 'Task';
         $this->fieldspec['idtasks']['abstract_data_type'] = 'integer';
         $this->fieldspec['idtasks']['db_data_type'] = 'integer';
         $this->fieldspec['idtasks']['field_null'] = 'NO';
         $this->fieldspec['idtasks']['field_key'] = '0';
         $this->fieldspec['idtasks']['extra_sql'] = ' ';
         $this->fieldspec['idtasks']['html_form_type'] = 'fddl';
         $this->fieldspec['idtasks']['html_form_options'] = '<fk><field>idtasks</field></fk>';
         $this->fieldspec['idtasks']['html_form_explanation'] = ' ';
         $this->fieldspec['idtasks']['help_text'] = ' ';
         $this->fieldspec['idtasks']['mandatory_p'] = 'Y';
         $this->fieldspec['idtasks']['sort_key'] = '0';
         $this->fieldspec['idtasks']['form_sort_key'] = '0';
         $this->fieldspec['idtasks']['form_number'] = '1';
         $this->fieldspec['idtasks']['default_value'] = ' ';
         $this->fieldspec['idtasks']['field_toupper'] = 'NO';
         $this->fieldspec['idtasks']['validationprocname'] = ' ';
         $this->fieldspec['idtasks']['c_size'] = '8';
         $this->fieldspec['idtasks']['prikey'] = 'N';
         $this->fieldspec['idtasks']['noedit'] = 'N';
         $this->fieldspec['idtasks']['nodisplay'] = 'N';
         $this->fieldspec['idtasks']['c_unsigned'] = 'N';
         $this->fieldspec['idtasks']['c_zerofill'] = 'N';
         $this->fieldspec['idtasks']['c_auto_increment'] = 'N';
         $this->fieldspec['idtasks']['foreign_table'] = 'tasks';
         $this->fieldspec['idtasks']['foreign_key'] = 'idtasks';
         $this->fieldspec['idtasks']['application'] = 'investing';
         $this->fieldspec['idtasks']['issearchable'] = '1';
         $this->fieldspec['rolenumber']['metadata_id'] = '2539';
         $this->fieldspec['rolenumber']['table_name'] = 'roletask';
         $this->fieldspec['rolenumber']['column_name'] = 'rolenumber';
         $this->fieldspec['rolenumber']['pretty_name'] = 'Role';
         $this->fieldspec['rolenumber']['abstract_data_type'] = 'integer';
         $this->fieldspec['rolenumber']['db_data_type'] = 'integer';
         $this->fieldspec['rolenumber']['field_null'] = 'NO';
         $this->fieldspec['rolenumber']['field_key'] = '0';
         $this->fieldspec['rolenumber']['extra_sql'] = ' ';
         $this->fieldspec['rolenumber']['html_form_type'] = 'fddl';
         $this->fieldspec['rolenumber']['html_form_options'] = '<fk><field>roledescription</field></fk>';
         $this->fieldspec['rolenumber']['html_form_explanation'] = ' ';
         $this->fieldspec['rolenumber']['help_text'] = ' ';
         $this->fieldspec['rolenumber']['mandatory_p'] = 'Y';
         $this->fieldspec['rolenumber']['sort_key'] = '0';
         $this->fieldspec['rolenumber']['form_sort_key'] = '0';
         $this->fieldspec['rolenumber']['form_number'] = '1';
         $this->fieldspec['rolenumber']['default_value'] = ' ';
         $this->fieldspec['rolenumber']['field_toupper'] = 'NO';
         $this->fieldspec['rolenumber']['validationprocname'] = ' ';
         $this->fieldspec['rolenumber']['c_size'] = '8';
         $this->fieldspec['rolenumber']['prikey'] = 'N';
         $this->fieldspec['rolenumber']['noedit'] = 'N';
         $this->fieldspec['rolenumber']['nodisplay'] = 'N';
         $this->fieldspec['rolenumber']['c_unsigned'] = 'N';
         $this->fieldspec['rolenumber']['c_zerofill'] = 'N';
         $this->fieldspec['rolenumber']['c_auto_increment'] = 'N';
         $this->fieldspec['rolenumber']['foreign_table'] = 'roles';
         $this->fieldspec['rolenumber']['foreign_key'] = 'rolenumber';
         $this->fieldspec['rolenumber']['application'] = 'investing';
         $this->fieldspec['rolenumber']['issearchable'] = '1';
         $this->fieldlist = array('idroletask', 'idtasks', 'rolenumber');
	         return SUCCESS;
         }
         function roletask()
         { //For older php which doesn't have constructor
         return $this->__constructor();
         }
         function Push()
         {
	         $_SESSION['roletask'] = serialize($this);
	         return SUCCESS;
         }
         function Pop()
         {
                 //Can't do this in self - this is how to do it outside
	       //  $this = unserialize($_SESSION['roletask']);
	         return SUCCESS;
         }
         function Setrolenumber($value)
         {
                  $this->fieldspec['rolenumber']['VALUE'] = $value;
	          return SUCCESS;
         }
         function Getrolenumber()
         {
                    return $this->fieldspec['rolenumber']['VALUE'];
         }
         function Validaterolenumber()
         {
         }
} /* class roletask */
