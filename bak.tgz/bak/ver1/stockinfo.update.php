<?php
require_once('stockinfo.class.php');
require_once('local.php');
$table = new stockinfo();
$mode = "update";
require_once('class.genericpage.php');
?>
