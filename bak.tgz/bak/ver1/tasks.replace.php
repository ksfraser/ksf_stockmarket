<?php
require_once('tasks.class.php');
require_once('local.php');
$table = new tasks();
$mode = "replace";
require_once('class.genericpage.php');
?>
