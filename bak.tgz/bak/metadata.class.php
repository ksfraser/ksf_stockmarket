<?php

//Create individual forms and classes from metadata

class my_metadata 
{
	var $mypage;
	var $action;
	var $method;
	
function enter_metadata_object()
{
$query_object_types = 'insert into metadata_object_types values($tablename, $prettyname, $prettyplural)';
return;
}

function enter_metadata_elements()
{
$query_elements = 'insert into metadata_elements values(NULL, $tablename, $columnname, 
			$prettyname, $abdatatype, $dbdatatype, $fieldtoupper, $fieldnull, 
			$fieldorder, $extrasql, $htmlformtype, $htmlformoptions, $htmlformexplain,
			$validationproc, $helptext, $mandatory, $sortkey, $formsortkey, $formnumber,
			$defaultvalue )';

return;
}

function my_metadata()
{
	require_once('page.php');
	$this->action = "metadata.php";
	$this->method = "POST";
	
	return;
}

function Display()
{
	$this->mypage->Display();
	$this->mypage->EndDisplay();
}

	
	
//create table if not exists metadata_elements (


function NewClass()
{
	$size = 30;
$this->mypage = new Page ("Metadata Entry Form New Database/Class", "Metadata Entry Form New Database/Class");
$entry_form = new Form( $this->action, $this->method );
$this->mypage->SetContent($entry_form);
$mytable = new Table();
$entry_form->SetTable($mytable);
$item = new Entry("Table Name", 'TEXT', 'tablename', $size, $size);
$mytable->SetEntry($item);
$item1 = new Entry("Pretty Name", 'TEXT', 'prettyname', $size, $size);
$mytable->SetEntry($item1);
$item2 = new Entry("Pretty Name Pluralized", 'TEXT', 'prettyplural', $size, $size);
$mytable->SetEntry($item2);
return;
}

function NewFields($tablename, $prettyname)
{
	$size = 30;
$this->mypage = new Page ("Metadata Entry Form New Fields", "Metadata Entry Form New Fields for $tablename");
$entry_form = new Form( $this->action, $this->method );
$this->mypage->SetContent($entry_form);
$mytable = new Table();
$entry_form->SetTable($mytable);

$item = new Hidden('tablename', $tablename);

$cell = new RowCell();
$row = new TRow();
$tbody = new TBody();

$cell->SetOption($item);
$row->SetOption($cell);
$tbody->SetOption($row);
$mytable->SetTBody($tbody);


$item1 = new Entry("Column (field) Name", 'TEXT', 'columnname', $size, $size);
//An entry is a pair of cells
$row1 = new TRow();
$row1->SetOption($item1);
$tbody->SetOption($row1);

$item2 = new Entry("Pretty Name", 'TEXT', 'prettyname', $size, $size);
$row2 = new TRow();
$row2->SetOption($item2);
$tbody->SetOption($row2);


$ddl = new DropDownList();
//DDL is a pair of cells.
$ddl->SetName("abdatatype");
$option = new DropDownOption("int", "Integer");
$option1 = new DropDownOption("float", "Float");
$option1a = new DropDownOption("text", "Text");
$option1b = new DropDownOption("timestamp", "Date and Time");
$option1c = new DropDownOption("set", "List (set)");
$option1d = new DropDownOption("enum", "Choice (enum)");
$ddl->SetOption($option);
$ddl->SetOption($option1);
$ddl->SetOption($option1a);
$ddl->SetOption($option1b);
$ddl->SetOption($option1c);
$ddl->SetOption($option1d);
$cell3 = new RowDataCell();
$cell3->SetDisplayText("Abstract Data Type");
$row3 = new TRow();
$row3->SetOption($cell3);
$row3->SetOption($ddl);
$tbody->SetOption($row3);


$ddl2 = new DropDownList();
$ddl2->SetName("dbdatatype");
$option2 = new DropDownOption("int", "Integer");
$option3 = new DropDownOption("float", "Floating Point/Double");
$option2a = new DropDownOption("decimal", "Decimal");
$option2b = new DropDownOption("date", "Date");
$option2c = new DropDownOption("datetime", "Date and Time");
$option2d = new DropDownOption("timestamp", "Time Stamp");
$option2e = new DropDownOption("time", "Time");
$option2f = new DropDownOption("year", "Year");
$option2g = new DropDownOption("char", "Characters");
$option2h = new DropDownOption("varchar", "Var Characters");
$option2i = new DropDownOption("text", "Text");
$option2j = new DropDownOption("enum", "Enum");
$option2k = new DropDownOption("set", "Set");
$option2l = new DropDownOption("blob", "Blob");
$option2m = new DropDownOption("longblob", "Long Blob");
$ddl2->SetOption($option2);
$ddl2->SetOption($option3);
$ddl2->SetOption($option2a);
$ddl2->SetOption($option2b);
$ddl2->SetOption($option2c);
$ddl2->SetOption($option2d);
$ddl2->SetOption($option2e);
$ddl2->SetOption($option2f);
$ddl2->SetOption($option2g);
$ddl2->SetOption($option2h);
$ddl2->SetOption($option2i);
$ddl2->SetOption($option2j);
$ddl2->SetOption($option2k);
$ddl2->SetOption($option2l);
$ddl2->SetOption($option2m);
$cell2 = new RowDataCell();
$cell2->SetDisplayText("Database Data Type");
$row15 = new TRow();
$row15->SetOption($cell2);
$row15->SetOption($ddl2);
$tbody->SetOption($row15);




$radio1 = new Radio("fieldnull", "yes", 0);
//A radio box is a cell to itself
$radio2 = new Radio("fieldnull", "no", 1);
$cell6 = new RowDataCell();
$cell6->SetDisplayText("Is Field NULL?");
$row4 = new TRow();
$row4->SetOption($cell6);
$row4->SetOption($radio1);
$row4->SetOption($radio2);
$tbody->SetOption($row4);



$radio3 = new Radio("mandatory", "yes", 1);
$radio4 = new Radio("mandatory", "no", 0);
$cell7 = new RowDataCell();
$cell7->SetDisplayText("Is Field Mandatory?");
$row5 = new TRow();
$row5->SetOption($cell7);
$row5->SetOption($radio3);
$row5->SetOption($radio4);
$tbody->SetOption($row5);


$radio5 = new Radio("fieldtoupper", "yes", 1);
$radio6 = new Radio("fieldtoupper", "no", 0);
$cell8 = new RowDataCell();
$cell8->SetDisplayText("Upper Case the field?");
$row6 = new TRow();
$row6->SetOption($cell8);
$row6->SetOption($radio5);
$row6->SetOption($radio6);
$tbody->SetOption($row6);


$item3 = new Entry("Field Order (number)", 'INT', fieldorder, 2, 2);
$row7 = new TRow();
$row7->SetOption($item3);
$tbody->SetOption($row7);


$item4 = new Entry("Extra Sql", 'TEXT', extrasql, 30, 30);
$row8 = new TRow();
$row8->SetOption($item4);
$tbody->SetOption($row8);


$item5 = new Entry("Sort Key (number)", 'INT', sortkey, 2, 2);
$row9 = new TRow();
$row9->SetOption($item5);
$tbody->SetOption($row9);

$item6 = new Entry("Form Sort Key (number)", 'INT', formsortkey, 2, 2);
$row10 = new TRow();
$row10->SetOption($item6);
$tbody->SetOption($row10);


$item7 = new Entry("Form Number (number)", 'INT', formnumber, 2, 2);
$row11 = new TRow();
$row11->SetOption($item7);
$tbody->SetOption($row11);


$item8 = new Entry("Default Value", 'TEXT', defaultvalue, 30, 30);
$row12 = new TRow();
$row12->SetOption($item8);
$tbody->SetOption($row12);


$item9 = new Entry("Form Short Explanation", 'TEXT', htmlformexplain, 30, 30);
$row13 = new TRow();
$row13->SetOption($item9);
$tbody->SetOption($row13);


$item10 = new Entry("Form Help (Explanation)", 'TEXT', helptext, 30, 30);
$row14 = new TRow();
$row14->SetOption($item10);
$tbody->SetOption($row14);


$ddl3 = new DropDownList();
$ddl3->SetName("htmlformtype");
$option4 = new DropDownOption("text", "Text");
$option5 = new DropDownOption("textarea", "text box");
$option4a = new DropDownOption("password", "Password Box");
$option4b = new DropDownOption("checkbox", "Check Box");
$option4c = new DropDownOption("radio", "Radio Box");
$option4d = new DropDownOption("image", "Image");
$option4e = new DropDownOption("hidden", "Hidden");
$option4f = new DropDownOption("submit", "Button (submit)");
$option4g = new DropDownOption("select", "Drop Down List");
$option4h = new DropDownOption("select", "Option Box");
$ddl3->SetOption($option4);
$ddl3->SetOption($option5);
$ddl3->SetOption($option4a);
$ddl3->SetOption($option4b);
$ddl3->SetOption($option4c);
$ddl3->SetOption($option4d);
$ddl3->SetOption($option4e);
$ddl3->SetOption($option4f);
$ddl3->SetOption($option4g);
$ddl3->SetOption($option4h);
$cell5 = new RowDataCell();
$cell5->SetDisplayText("HTML Form Type");
$row15 = new TRow();
$row15->SetOption($cell5);
$row15->SetOption($ddl3);
$tbody->SetOption($row15);


$ddl4 = new DropDownList();
$ddl4->SetName("validationproc");
$option6 = new DropDownOption("No Validation Procedure", "none");
$option7 = new DropDownOption( "Prove Integer", "validateinteger");
$ddl4->SetOption($option6);
$ddl4->SetOption($option7);
$cell4 = new RowDataCell();
$cell4->SetDisplayText("Validation Procedure");
$row15 = new TRow();
$row15->SetOption($cell4);
$row15->SetOption($ddl4);
$tbody->SetOption($row15);

$item11 = new Entry("Form Options (ie size=9)", 'TEXT', htmlformoptions, 30, 30);
$row16 = new TRow();
$row16->SetOption($item11);
$tbody->SetOption($row16);


return;
}

}


?>
