<?php
require_once('roletask.class.php');
require_once('local.php');
$table = new roletask();
$mode = "delete";
require_once('controller/controller.php');
?>
