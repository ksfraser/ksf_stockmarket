---
--- Table struct for table transactiontype
---
DROP TABLE IF EXISTS `transactiontype`;
CREATE TABLE `transactiontype` (
`transactiontype` varchar(45)   NOT NULL  default ' ' comment 'Transaction Type'
PRIMARY KEY ('')
) ENGINE=myIsam DEFAULT CHARSET=latin1;
