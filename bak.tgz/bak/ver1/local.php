<?php

//this script may only be included - so its better to die if called directly.
if (strpos($_SERVER["SCRIPT_NAME"],basename(__FILE__)) !== false) {
header("location: index.php");
exit;
}

	function Local_DB()
	{
		require_once('db.php');
                $db = new my_db( 'localhost', 'invest', 'invest', 'stocks');
		return $db;
	}

	
?>
