<?php
require_once('stockinfo.class.php');
require_once('local.php');
$table = new stockinfo();
$mode = "replace";
require_once('controller/controller.php');
?>
