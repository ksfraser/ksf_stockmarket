---
--- Table struct for table users
---
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
`emailaddress` varchar(255)   NOT NULL  default ' ' comment 'Email Address',
`firstname` varchar(45)   NOT NULL  default ' ' comment 'Firstname',
`password` varchar(45)   NOT NULL  default ' ' comment 'Password',
`role` integer(8)   NOT NULL  default ' ' comment 'Role Access Control',
`surname` varchar(45)   NOT NULL  default ' ' comment 'Surname',
`username` varchar(255)   NOT NULL  default ' ' comment 'UserName'
PRIMARY KEY ('')
) ENGINE=myIsam DEFAULT CHARSET=latin1;
