<?php
require_once('transaction.class.php');
require_once('local.php');
$table = new transaction();
$mode = "insert";
require_once('class.genericpage.php');
?>
