<?php
require_once('users.class.php');
require_once('local.php');
$table = new users();
$mode = "delete";
require_once('class.genericpage.php');
?>
