---
--- Table struct for table stockinfo
---
DROP TABLE IF EXISTS `stockinfo`;
CREATE TABLE `stockinfo` (
`symbol` char(4)   NOT NULL  default ' ' comment 'Stock Symbol',
`exchange` varchar(255)   NOT NULL  default ' ' comment 'Stock Exchange',
`corporatename` varchar(255)   NOT NULL  default ' ' comment 'Corporate Name',
`52high` float(8)   NOT NULL  default ' ' comment '52 Week High',
`52low` float(8)   NOT NULL  default ' ' comment '52 Week Low',
`low` float(8)   NOT NULL  default ' ' comment 'Low',
`high` float(8)   NOT NULL  default ' ' comment 'High'
PRIMARY KEY (``)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
