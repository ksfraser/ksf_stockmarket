<?php 
//this script may only be included - so its better to die if called directly.
if (strpos($_SERVER["SCRIPT_NAME"],basename(__FILE__)) !== false) {
  header("location: index.php");
  exit;
}
require_once('class.generictable.php');
require_once('roles.class.inc.php');
class roles extends generictable{
         function __constructor()
         {
         $this->querytablename = 'roles';
         $this->fieldspec['roledesc']['metadata_id'] = '2534';
         $this->fieldspec['roledesc']['table_name'] = 'roles';
         $this->fieldspec['roledesc']['column_name'] = 'roledesc';
         $this->fieldspec['roledesc']['pretty_name'] = 'Role Description';
         $this->fieldspec['roledesc']['abstract_data_type'] = 'string';
         $this->fieldspec['roledesc']['db_data_type'] = 'varchar';
         $this->fieldspec['roledesc']['field_null'] = 'NO';
         $this->fieldspec['roledesc']['field_key'] = '0';
         $this->fieldspec['roledesc']['extra_sql'] = ' ';
         $this->fieldspec['roledesc']['html_form_type'] = 'char';
         $this->fieldspec['roledesc']['html_form_options'] = ' ';
         $this->fieldspec['roledesc']['html_form_explanation'] = ' ';
         $this->fieldspec['roledesc']['help_text'] = ' ';
         $this->fieldspec['roledesc']['mandatory_p'] = 'Y';
         $this->fieldspec['roledesc']['sort_key'] = '0';
         $this->fieldspec['roledesc']['form_sort_key'] = '0';
         $this->fieldspec['roledesc']['form_number'] = '1';
         $this->fieldspec['roledesc']['default_value'] = ' ';
         $this->fieldspec['roledesc']['field_toupper'] = 'YES';
         $this->fieldspec['roledesc']['validationprocname'] = ' ';
         $this->fieldspec['roledesc']['c_size'] = '45';
         $this->fieldspec['roledesc']['prikey'] = 'N';
         $this->fieldspec['roledesc']['noedit'] = 'N';
         $this->fieldspec['roledesc']['nodisplay'] = 'N';
         $this->fieldspec['roledesc']['c_unsigned'] = 'N';
         $this->fieldspec['roledesc']['c_zerofill'] = 'N';
         $this->fieldspec['roledesc']['c_auto_increment'] = 'N';
         $this->fieldspec['roledesc']['foreign_table'] = ' ';
         $this->fieldspec['roledesc']['foreign_key'] = ' ';
         $this->fieldspec['roledesc']['application'] = 'investing';
         $this->fieldspec['roledesc']['issearchable'] = '1';
         $this->fieldspec['rolenumber']['metadata_id'] = '2535';
         $this->fieldspec['rolenumber']['table_name'] = 'roles';
         $this->fieldspec['rolenumber']['column_name'] = 'rolenumber';
         $this->fieldspec['rolenumber']['pretty_name'] = 'Role Index';
         $this->fieldspec['rolenumber']['abstract_data_type'] = 'flags';
         $this->fieldspec['rolenumber']['db_data_type'] = 'integer';
         $this->fieldspec['rolenumber']['field_null'] = 'NO';
         $this->fieldspec['rolenumber']['field_key'] = '0';
         $this->fieldspec['rolenumber']['extra_sql'] = ' ';
         $this->fieldspec['rolenumber']['html_form_type'] = 'hidden';
         $this->fieldspec['rolenumber']['html_form_options'] = ' ';
         $this->fieldspec['rolenumber']['html_form_explanation'] = ' ';
         $this->fieldspec['rolenumber']['help_text'] = ' ';
         $this->fieldspec['rolenumber']['mandatory_p'] = 'Y';
         $this->fieldspec['rolenumber']['sort_key'] = '0';
         $this->fieldspec['rolenumber']['form_sort_key'] = '0';
         $this->fieldspec['rolenumber']['form_number'] = '1';
         $this->fieldspec['rolenumber']['default_value'] = '0';
         $this->fieldspec['rolenumber']['field_toupper'] = 'NO';
         $this->fieldspec['rolenumber']['validationprocname'] = ' ';
         $this->fieldspec['rolenumber']['c_size'] = '8';
         $this->fieldspec['rolenumber']['prikey'] = 'N';
         $this->fieldspec['rolenumber']['noedit'] = 'N';
         $this->fieldspec['rolenumber']['nodisplay'] = 'N';
         $this->fieldspec['rolenumber']['c_unsigned'] = 'N';
         $this->fieldspec['rolenumber']['c_zerofill'] = 'N';
         $this->fieldspec['rolenumber']['c_auto_increment'] = 'N';
         $this->fieldspec['rolenumber']['foreign_table'] = ' ';
         $this->fieldspec['rolenumber']['foreign_key'] = ' ';
         $this->fieldspec['rolenumber']['application'] = 'investing';
         $this->fieldspec['rolenumber']['issearchable'] = '1';
         $this->fieldlist = array('roledesc', 'rolenumber');
	         return SUCCESS;
         }
         function roles()
         { //For older php which doesn't have constructor
         return $this->__constructor();
         }
         function Push()
         {
	         $_SESSION['roles'] = serialize($this);
	         return SUCCESS;
         }
         function Pop()
         {
                 //Can't do this in self - this is how to do it outside
	       //  $this = unserialize($_SESSION['roles']);
	         return SUCCESS;
         }
         function Setrolenumber($value)
         {
                  $this->fieldspec['rolenumber']['VALUE'] = $value;
	          return SUCCESS;
         }
         function Getrolenumber()
         {
                    return $this->fieldspec['rolenumber']['VALUE'];
         }
         function Validaterolenumber()
         {
         }
} /* class roles */
