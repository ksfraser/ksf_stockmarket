<?php 
//this script may only be included - so its better to die if called directly.
if (strpos($_SERVER["SCRIPT_NAME"],basename(__FILE__)) !== false) {
  header("location: index.php");
  exit;
}

require_once('class.generictable.php');
require_once('tasks.class.inc.php');
class tasks extends generictable{
         function __constructor()
         {
         $this->querytablename = 'tasks';
         $this->fieldspec['idtasks']['metadata_id'] = '2536';
         $this->fieldspec['idtasks']['table_name'] = 'tasks';
         $this->fieldspec['idtasks']['column_name'] = 'idtasks';
         $this->fieldspec['idtasks']['pretty_name'] = 'Task Index';
         $this->fieldspec['idtasks']['abstract_data_type'] = 'index';
         $this->fieldspec['idtasks']['db_data_type'] = 'integer';
         $this->fieldspec['idtasks']['field_null'] = 'NO';
         $this->fieldspec['idtasks']['field_key'] = '0';
         $this->fieldspec['idtasks']['extra_sql'] = ' ';
         $this->fieldspec['idtasks']['html_form_type'] = 'integer';
         $this->fieldspec['idtasks']['html_form_options'] = ' ';
         $this->fieldspec['idtasks']['html_form_explanation'] = ' ';
         $this->fieldspec['idtasks']['help_text'] = ' ';
         $this->fieldspec['idtasks']['mandatory_p'] = 'Y';
         $this->fieldspec['idtasks']['sort_key'] = '0';
         $this->fieldspec['idtasks']['form_sort_key'] = '0';
         $this->fieldspec['idtasks']['form_number'] = '1';
         $this->fieldspec['idtasks']['default_value'] = '0';
         $this->fieldspec['idtasks']['field_toupper'] = 'NO';
         $this->fieldspec['idtasks']['validationprocname'] = ' ';
         $this->fieldspec['idtasks']['c_size'] = '8';
         $this->fieldspec['idtasks']['prikey'] = 'Y';
         $this->fieldspec['idtasks']['noedit'] = 'N';
         $this->fieldspec['idtasks']['nodisplay'] = 'N';
         $this->fieldspec['idtasks']['c_unsigned'] = 'N';
         $this->fieldspec['idtasks']['c_zerofill'] = 'N';
         $this->fieldspec['idtasks']['c_auto_increment'] = 'N';
         $this->fieldspec['idtasks']['foreign_table'] = ' ';
         $this->fieldspec['idtasks']['foreign_key'] = ' ';
         $this->fieldspec['idtasks']['application'] = 'investing';
         $this->fieldspec['idtasks']['issearchable'] = '1';
         $this->fieldspec['parent']['metadata_id'] = '2543';
         $this->fieldspec['parent']['table_name'] = 'tasks';
         $this->fieldspec['parent']['column_name'] = 'parent';
         $this->fieldspec['parent']['pretty_name'] = 'Parent Menu Item';
         $this->fieldspec['parent']['abstract_data_type'] = 'string';
         $this->fieldspec['parent']['db_data_type'] = 'varchar';
         $this->fieldspec['parent']['field_null'] = 'NO';
         $this->fieldspec['parent']['field_key'] = '0';
         $this->fieldspec['parent']['extra_sql'] = ' ';
         $this->fieldspec['parent']['html_form_type'] = 'char';
         $this->fieldspec['parent']['html_form_options'] = ' ';
         $this->fieldspec['parent']['html_form_explanation'] = ' ';
         $this->fieldspec['parent']['help_text'] = ' ';
         $this->fieldspec['parent']['mandatory_p'] = 'Y';
         $this->fieldspec['parent']['sort_key'] = '0';
         $this->fieldspec['parent']['form_sort_key'] = '0';
         $this->fieldspec['parent']['form_number'] = '1';
         $this->fieldspec['parent']['default_value'] = ' ';
         $this->fieldspec['parent']['field_toupper'] = 'YES';
         $this->fieldspec['parent']['validationprocname'] = ' ';
         $this->fieldspec['parent']['c_size'] = '45';
         $this->fieldspec['parent']['prikey'] = 'N';
         $this->fieldspec['parent']['noedit'] = 'N';
         $this->fieldspec['parent']['nodisplay'] = 'N';
         $this->fieldspec['parent']['c_unsigned'] = 'N';
         $this->fieldspec['parent']['c_zerofill'] = 'N';
         $this->fieldspec['parent']['c_auto_increment'] = 'N';
         $this->fieldspec['parent']['foreign_table'] = ' ';
         $this->fieldspec['parent']['foreign_key'] = ' ';
         $this->fieldspec['parent']['application'] = 'investing';
         $this->fieldspec['parent']['issearchable'] = '1';
         $this->fieldspec['taskdescription']['metadata_id'] = '2541';
         $this->fieldspec['taskdescription']['table_name'] = 'tasks';
         $this->fieldspec['taskdescription']['column_name'] = 'taskdescription';
         $this->fieldspec['taskdescription']['pretty_name'] = 'Task Description';
         $this->fieldspec['taskdescription']['abstract_data_type'] = 'string';
         $this->fieldspec['taskdescription']['db_data_type'] = 'varchar';
         $this->fieldspec['taskdescription']['field_null'] = 'NO';
         $this->fieldspec['taskdescription']['field_key'] = '0';
         $this->fieldspec['taskdescription']['extra_sql'] = ' ';
         $this->fieldspec['taskdescription']['html_form_type'] = 'char';
         $this->fieldspec['taskdescription']['html_form_options'] = ' ';
         $this->fieldspec['taskdescription']['html_form_explanation'] = ' ';
         $this->fieldspec['taskdescription']['help_text'] = ' ';
         $this->fieldspec['taskdescription']['mandatory_p'] = 'Y';
         $this->fieldspec['taskdescription']['sort_key'] = '0';
         $this->fieldspec['taskdescription']['form_sort_key'] = '0';
         $this->fieldspec['taskdescription']['form_number'] = '1';
         $this->fieldspec['taskdescription']['default_value'] = ' ';
         $this->fieldspec['taskdescription']['field_toupper'] = 'YES';
         $this->fieldspec['taskdescription']['validationprocname'] = ' ';
         $this->fieldspec['taskdescription']['c_size'] = '45';
         $this->fieldspec['taskdescription']['prikey'] = 'N';
         $this->fieldspec['taskdescription']['noedit'] = 'N';
         $this->fieldspec['taskdescription']['nodisplay'] = 'N';
         $this->fieldspec['taskdescription']['c_unsigned'] = 'N';
         $this->fieldspec['taskdescription']['c_zerofill'] = 'N';
         $this->fieldspec['taskdescription']['c_auto_increment'] = 'N';
         $this->fieldspec['taskdescription']['foreign_table'] = ' ';
         $this->fieldspec['taskdescription']['foreign_key'] = ' ';
         $this->fieldspec['taskdescription']['application'] = 'investing';
         $this->fieldspec['taskdescription']['issearchable'] = '1';
         $this->fieldspec['tasklink']['metadata_id'] = '2542';
         $this->fieldspec['tasklink']['table_name'] = 'tasks';
         $this->fieldspec['tasklink']['column_name'] = 'tasklink';
         $this->fieldspec['tasklink']['pretty_name'] = 'Link for Task/Menu';
         $this->fieldspec['tasklink']['abstract_data_type'] = 'string';
         $this->fieldspec['tasklink']['db_data_type'] = 'varchar';
         $this->fieldspec['tasklink']['field_null'] = 'NO';
         $this->fieldspec['tasklink']['field_key'] = '0';
         $this->fieldspec['tasklink']['extra_sql'] = ' ';
         $this->fieldspec['tasklink']['html_form_type'] = 'char';
         $this->fieldspec['tasklink']['html_form_options'] = ' ';
         $this->fieldspec['tasklink']['html_form_explanation'] = ' ';
         $this->fieldspec['tasklink']['help_text'] = ' ';
         $this->fieldspec['tasklink']['mandatory_p'] = 'Y';
         $this->fieldspec['tasklink']['sort_key'] = '0';
         $this->fieldspec['tasklink']['form_sort_key'] = '0';
         $this->fieldspec['tasklink']['form_number'] = '1';
         $this->fieldspec['tasklink']['default_value'] = ' ';
         $this->fieldspec['tasklink']['field_toupper'] = 'NO';
         $this->fieldspec['tasklink']['validationprocname'] = ' ';
         $this->fieldspec['tasklink']['c_size'] = '45';
         $this->fieldspec['tasklink']['prikey'] = 'N';
         $this->fieldspec['tasklink']['noedit'] = 'N';
         $this->fieldspec['tasklink']['nodisplay'] = 'N';
         $this->fieldspec['tasklink']['c_unsigned'] = 'N';
         $this->fieldspec['tasklink']['c_zerofill'] = 'N';
         $this->fieldspec['tasklink']['c_auto_increment'] = 'N';
         $this->fieldspec['tasklink']['foreign_table'] = ' ';
         $this->fieldspec['tasklink']['foreign_key'] = ' ';
         $this->fieldspec['tasklink']['application'] = 'investing';
         $this->fieldspec['tasklink']['issearchable'] = '1';
         $this->fieldspec['tasktype']['metadata_id'] = '2537';
         $this->fieldspec['tasktype']['table_name'] = 'tasks';
         $this->fieldspec['tasktype']['column_name'] = 'tasktype';
         $this->fieldspec['tasktype']['pretty_name'] = 'Task Type';
         $this->fieldspec['tasktype']['abstract_data_type'] = 'string';
         $this->fieldspec['tasktype']['db_data_type'] = 'varchar';
         $this->fieldspec['tasktype']['field_null'] = 'YES';
         $this->fieldspec['tasktype']['field_key'] = '0';
         $this->fieldspec['tasktype']['extra_sql'] = ' ';
         $this->fieldspec['tasktype']['html_form_type'] = 'char';
         $this->fieldspec['tasktype']['html_form_options'] = ' ';
         $this->fieldspec['tasktype']['html_form_explanation'] = ' ';
         $this->fieldspec['tasktype']['help_text'] = ' ';
         $this->fieldspec['tasktype']['mandatory_p'] = 'Y';
         $this->fieldspec['tasktype']['sort_key'] = '0';
         $this->fieldspec['tasktype']['form_sort_key'] = '0';
         $this->fieldspec['tasktype']['form_number'] = '1';
         $this->fieldspec['tasktype']['default_value'] = 'TASK';
         $this->fieldspec['tasktype']['field_toupper'] = 'YES';
         $this->fieldspec['tasktype']['validationprocname'] = ' ';
         $this->fieldspec['tasktype']['c_size'] = '45';
         $this->fieldspec['tasktype']['prikey'] = 'N';
         $this->fieldspec['tasktype']['noedit'] = 'N';
         $this->fieldspec['tasktype']['nodisplay'] = 'N';
         $this->fieldspec['tasktype']['c_unsigned'] = 'N';
         $this->fieldspec['tasktype']['c_zerofill'] = 'N';
         $this->fieldspec['tasktype']['c_auto_increment'] = 'N';
         $this->fieldspec['tasktype']['foreign_table'] = ' ';
         $this->fieldspec['tasktype']['foreign_key'] = ' ';
         $this->fieldspec['tasktype']['application'] = 'investing';
         $this->fieldspec['tasktype']['issearchable'] = '1';
         $this->fieldlist = array('idtasks', 'parent', 'taskdescription', 'tasklink', 'tasktype');
	         return SUCCESS;
         }
         function tasks()
         { //For older php which doesn't have constructor
         return $this->__constructor();
         }
         function Push()
         {
	         $_SESSION['tasks'] = serialize($this);
	         return SUCCESS;
         }
         function Pop()
         {
                 //Can't do this in self - this is how to do it outside
	       //  $this = unserialize($_SESSION['tasks']);
	         return SUCCESS;
         }
         function Settasktype($value)
         {
                  $this->fieldspec['tasktype']['VALUE'] = $value;
	          return SUCCESS;
         }
         function Gettasktype()
         {
                    return $this->fieldspec['tasktype']['VALUE'];
         }
         function Validatetasktype()
         {
         }
} /* class tasks */
