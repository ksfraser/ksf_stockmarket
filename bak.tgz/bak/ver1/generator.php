<?php

	require_once('db.php');
	define ("SUCCESS", 1);
	define ("TRUE", 1);
	define ("FALSE", 0);

/* Homebuilt code generator.  Will go into MySQL db to get the description of the tables, will build classes to handle CRUD for those tables, will include SQL scripts to create tables, etc.

GUI generation could also use XML descriptions.
*/


/*
Want to build classes in file named TABLENAME.class.php

define TRUE;
define FALSE;
define SUCCESS;

class TABLENAME {
	var $fieldspec = array('firstcol', 'secondcol', ...);
	var $firstcol = array( value, dbtype, htmltype, ...); //Comment on datatype, size, etc.
	var $secondcol;
	...
	function __contsructor()
	{
		return;
	}
	function Setfirstcol($value)
	{
		$this->firstcol = $value;
		return SUCCESS;
	}
	function Getfirstcol()
	{
		return $this->firstcol;
	}
	function Validatefirstcol()
	{
		if (iscoltype($value))
		{
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}
	...
}

*/


class my_generator
{
	var $tablename;
	var $query;
	var $result;
	var $db; //connection, not name

function __constructor($table)
{
	$this->Settablename($table);
	$this->includefilename = $this->tablename . ".class.inc.php"; 
	$this->classfilename = $this->tablename . ".class.php"; 
	echo "Table Name: $table";
	return SUCCESS;
}
function my_generator($table)
{
	return $this->__constructor($table);
}

function sql_GetObjectQuery()
{
	return "select * from $this->tablename";
}

function fp_OpenClassFile()
{
	$fp = fopen( $this->classfilename, "w" );
	if ($fp == NULL)
	{
		//error - log it
		exit(0);
	}
	else
	{
		return $fp;
	}
}

function fp_OpenClassHeaderFile()
{
	$fp = fopen( $this->includefilename, "w" );
	if ($fp == NULL)
	{
		//error - log it
		exit(0);
	}
	else
	{
		return $fp;
	}
}

function fp_OpenXSLTFile()
{
	$filename = $this->tablename . ".xslt"; 
	$fp = fopen( $filename, "w" );
	if ($fp == NULL)
	{
		//error - log it
		exit(0);
	}
	else
	{
		return $fp;
	}
}

function b_CreateHeader()
{
	$headerstring = "<?php \n";
	//$headerstring .= "require_once('db.php'); \n"; 
	//$headerstring .= "require_once('page.php'); \n"; 
//	$headerstring .= "require_once('datatypes.inc'); \n"; 
	$headerstring .= "?>";
	$fp = $this->fp_OpenClassHeaderFile();
	fwrite( $fp, $headerstring );
	fclose ($fp);
	return SUCCESS;
}

function b_CreateClassFile($queryresults, $colres, $colres2)
{
	$funcstring = "";
	$colstring = "";
	
	$filestring = "<?php \n";
	$filestring .= "//this script may only be included - so its better to die if called directly.\n";
$filestring .= "if (strpos($" . "_SERVER[\"SCRIPT_NAME\"],basename(__FILE__)) !== false) {\n";
$filestring .= "  header(\"location: index.php\");\n";
$filestring .= "  exit;\n";
$filestring .= "}\n\n";

	$filestring .= "require_once('class.generictable.php');\n";
	$filestring .= "require_once('" . $this->includefilename . "');\n";
	$filestring .= "class $this->tablename extends generictable{\n";
	//Build Variables List
	$fieldstring = "         \$this->fieldlist = array('";
	$colstring .= "         \$this->querytablename = '" . $this->tablename . "';\n";
	while ($res = $this->GetRow($colres)) //implicit !NULL
	{	
		$fieldstring .= $res['column_name'];
		$fieldstring .= "', '";
		
		$totalcount = count ($res);
		$arrcount = count( $res[0] );
		$colcount = $totalcount / $arrcount;
		$keys = $arrcount / 2;
		for ($j = 0; $j < $colcount; $j++)
		{
		  for ($i = 0; $i < $keys; $i++)
		  {
			  //Errors out about unsetting string offsets
			//unset( $res[$j]['$i'] );
		  }
	  	}
		foreach ($res as $key => $value)
		{
			if (FALSE == is_numeric($key))
			{
				$colstring .= "         \$this->fieldspec['" . $res['column_name'] . "']['$key'] = '$value';\n";
			}
		}
		$funcstring2 = "         function Set" . $res['column_name'] . "(\$value)\n";
		$funcstring2 .= "         {\n";
		$funcstring2 .= "                  \$this->fieldspec['";
	       	$funcstring2 .= $res['column_name']; 
		$funcstring2 .= "']['VALUE'] = \$value;\n";
		$funcstring2 .= "	          return SUCCESS;\n";
		$funcstring2 .= "         }\n";
		$funcstring2 .= "         function Get" . $res['column_name'] ."()\n";
		$funcstring2 .= "         {\n  ";
		$funcstring2 .= "                  return \$this->fieldspec['" . $res['column_name'] . "']['VALUE'];\n";
		$funcstring2 .= "         }\n";
		$funcstring2 .= "         function Validate" . $res['column_name'] . "()\n";
		$funcstring2 .= "         {\n";
		/*
		$funcstring2 .= "                  if (" . iscoltype . "(\$value))\n";
		$funcstring2 .= "                  {\n";
		$funcstring2 .= "                           return TRUE;\n";
		$funcstring2 .= "                  }\n";	
		$funcstring2 .= "                  else\n";	
		$funcstring2 .= "                  {\n";
		$funcstring2 .= "                           return FALSE;\n";
		$funcstring2 .= "                  }\n";
		*/
		$funcstring2 .= "         }\n";
	}
	$fieldstring = rtrim( $fieldstring, "', "); //remove the last comma as it is extra due to the above while loop.
	$fieldstring .= "');\n";
	$funcstring .= "         function __constructor()\n";
		$funcstring .= "         {\n";
		$funcstring .= $colstring;
		$funcstring .= $fieldstring;
		$funcstring .= "	         return SUCCESS;\n";
		$funcstring .= "         }\n";
		$funcstring .= "         function $this->tablename()\n";
		$funcstring .= "         { //For older php which doesn't have constructor\n";
		$funcstring .= "         return \$this->__constructor();\n";
		$funcstring .= "         }\n";
		$funcstring .= "         function Push()\n";
		$funcstring .= "         {\n";	
		$funcstring .= "	         \$_SESSION['$this->tablename'] = serialize(\$this);\n";
		$funcstring .= "	         return SUCCESS;\n";	
		$funcstring .= "         }\n";
		$funcstring .= "         function Pop()\n";
		$funcstring .= "         {\n";	
		$funcstring .= "                 //Can't do this in self - this is how to do it outside\n";
		$funcstring .= "	       //  \$this = unserialize(\$_SESSION['$this->tablename']);\n";
		$funcstring .= "	         return SUCCESS;\n";
		$funcstring .= "         }\n";
		
	//Set attributes of the columns into arrays
	$output = $filestring . $funcstring . $funcstring2;
	$output .= "} /* class $this->tablename */\n";
	$fp = $this->fp_OpenClassFile();
	fwrite( $fp, $output );
	fclose ($fp);

	return SUCCESS;
}

function b_CreateXSLTFile($queryresults, $colres, $colres2)
{	
	
	$topstring = ' <xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" xmlns="HTTP://WWW.W3.ORG/1999/XHTML">';

	$matchstring = '<xsl:template match="/"> <xsl:apply-templates select="ROOT/*" /> </xsl:template>';

	$setstring = '<xsl:template match="RECORDSET"> <xsl:apply-templates/> </xsl:template>';
	$recordstring = '<xsl:template match="RECORD"> <xsl:apply-templates/> </xsl:template>';
	$rowstring = "";
	while ($res = $this->GetRow($colres)) //implicit !NULL
	{	
		$rowstring .= '<xsl:template match="' . $res['column_name'] . '"> <xsl:apply-templates/> </xsl:template>';
	}
	$endstring = '</xsl:stylesheet>';
	
	$output = $topstring . $matchstring . $setstring . $recordstring . $rowstring . $endstring;
	$fp = $this->fp_OpenXSLTFile();
	fwrite( $fp, $output );
	fclose ($fp);

	return SUCCESS;
}

function Settablename($name)
{
	$this->tablename = $name;
	return SUCCESS;
}
function BuildQuery()
{
	$this->query = "select * from codemeta.metadata_elements where table_name = '$this->tablename'";
	return SUCCESS;
}
function Query()
{
	$this->db = new my_db("localhost", "codemeta", "codemeta", "codemeta");
	$this->db->SetQuery($this->query);
	$this->db->Query();
	$this->result = $this->db->result;
	return SUCCESS;
}
function GetRow($res)
{
	$this->db->result = $res;
	return $this->db->FetchRow();
}

function CreateObjects()
{
	$this->BuildQuery();
	$this->Query();
	$res = $this->result;
	$this->b_CreateClassFile($res, $res, $res);
	$this->b_CreateHeader();
	return SUCCESS;
}


function CreateXSLT()
{
	$this->BuildQuery();
	$this->Query();
	$res = $this->result;
	$this->b_CreateXSLTFile($res, $res, $res);
	return SUCCESS;
}


function b_CreateSQLFile($result)
{
	$prikeyar = array();
	$statement ="---\n"; 
	$statement .="--- Table struct for table $this->tablename\n"; 
	$statement .="---\n"; 
	$statement .= "DROP TABLE IF EXISTS `$this->tablename`;\n";
	$statement .= "CREATE TABLE `$this->tablename` (\n";
	while ($row = $this->GetRow($result))
	{
		//Init values
		$column = $type = $size = $unsigned = $zerofill = $NULL = $autoinc = $default = $comment = $PRIKEY = "";
		$column = $row['column_name'];
		$type = $row['db_data_type'];
		$size = $row['c_size'];
		if ($row['c_unsigned'] == 'Y')
		{
			$unsigned = "unsigned";
		}
		if ($row['c_zerofill'] == 'Y')
		{
			$zerofill = "zerofill";
		}
		if (strncmp($row['field_null'], "Y", 1) == 0)
		{
			$NULL = "NULL";
		}
		else
		{
			$NULL = "NOT NULL";
		}	
		if ($row['c_auto_increment'] == 'Y')
		{
			$autoinc = "auto_increment";
		}
		if ($row['prikey'] == 'Y')
		{
			$prikeyar[] = $row['column_name'];
			var_dump($prikeyar);
		}
		$defval = $row['default_value'];
		$default = "default '$defval'";
		$commentval = $row['pretty_name'];
		$comment = "comment '$commentval'";
		//If Comment -> COMMENT ''
		//If default -> default ''
		//PRIKEY = (`key1`, `key2`)
		$statement .= "`$column` $type($size) $unsigned $zerofill $NULL $autoinc $default $comment,\n";
	}
	$statement = rtrim( rtrim( $statement ), ",");
	if (count($prikeyar) < 2)
	{
		$PRIKEY = "'" . $prikeyar[0] . "'";
	}
	else
	{
		$PRIKEY = "'" . $prikeyar[0] . "'";
		foreach ($prikeyar as $key=> $value)
		{
			$PRIKEY .= ", '" . $value . "'";
		}
	}
	$statement .= "\nPRIMARY KEY ($PRIKEY)\n";
	$statement .= ") ENGINE=myIsam DEFAULT CHARSET=latin1;\n";
	$fp = fopen($this->tablename . ".sql", "w");
	fputs( $fp, $statement );
	fclose( $fp );
}


function CreateTableSQL()
{
	$this->BuildQuery();
	$this->Query();
	$res = $this->result;
	$this->b_CreateSQLFile($res, $res, $res);
	return SUCCESS;
}


function CreatePatterns()
{
	//Create the files for list, update, delete, insert
	$filename = $this->tablename . ".insert.php"; 
	$fp = fopen( $filename, "w" );
	if ($fp == NULL)
	{
		//error - log it
		exit(0);
	}
	$output = "<?php\n";
	$output .= "require_once('" . $this->classfilename . "');\n";
	$output .= "require_once('local.php');\n";
	$output .= "\$table = new " . $this->tablename . "();\n";
	$output .= '$mode = "insert";' . "\n";
	$output .= "require_once('class.genericpage.php');\n";
	$output .= "?>\n";
	fwrite( $fp, $output );
	fclose ($fp);

	$filename = $this->tablename . ".replace.php"; 
	$fp = fopen( $filename, "w" );
	if ($fp == NULL)
	{
		//error - log it
		exit(0);
	}
	$output = "<?php\n";
	$output .= "require_once('" . $this->classfilename . "');\n";
	$output .= "require_once('local.php');\n";
	$output .= "\$table = new " . $this->tablename . "();\n";
	$output .= '$mode = "replace";' . "\n";
	$output .= "require_once('class.genericpage.php');\n";
	$output .= "?>\n";
	fwrite( $fp, $output );
	fclose ($fp);

	$filename = $this->tablename . ".update.php"; 
	$fp = fopen( $filename, "w" );
	if ($fp == NULL)
	{
		//error - log it
		exit(0);
	}
	$output = "<?php\n";
	$output .= "require_once('" . $this->classfilename . "');\n";
	$output .= "require_once('local.php');\n";
	$output .= "\$table = new " . $this->tablename . "();\n";
	$output .= '$mode = "update";' . "\n";
	$output .= "require_once('class.genericpage.php');\n";
	$output .= "?>\n";
	fwrite( $fp, $output );
	fclose ($fp);

	$filename = $this->tablename . ".delete.php"; 
	$fp = fopen( $filename, "w" );
	if ($fp == NULL)
	{
		//error - log it
		exit(0);
	}
	$output = "<?php\n";
	$output .= "require_once('" . $this->classfilename . "');\n";
	$output .= "require_once('local.php');\n";
	$output .= "\$table = new " . $this->tablename . "();\n";
	$output .= '$mode = "delete";' . "\n";
	$output .= "require_once('class.genericpage.php');\n";
	$output .= "?>\n";
	fwrite( $fp, $output );
	fclose ($fp);

	$filename = $this->tablename . ".list.php"; 
	$fp = fopen( $filename, "w" );
	if ($fp == NULL)
	{
		//error - log it
		exit(0);
	}
	$output = "<?php\n";
	$output .= "require_once('" . $this->classfilename . "');\n";
	$output .= "require_once('local.php');\n";
	$output .= "\$table = new " . $this->tablename . "();\n";
	$output .= '$mode = "list";' . "\n";
	$output .= "require_once('class.genericpage.php');\n";
	$output .= "?>\n";
	fwrite( $fp, $output );
	fclose ($fp);
}

} /*class my_generator*/

$includefilename = ""; 
$classfilename = ""; 

$mydb = new my_db("localhost", "codemeta", "codemeta", "codemeta");
if (isset($argv[1]))
{
	$mydb->SetQuery("select distinct(table_name) from codemeta.metadata_elements where application='$argv[1]'");
}
else
{
	$mydb->SetQuery("select distinct(table_name) from codemeta.metadata_elements");
}
$result = $mydb->Query();
while ($res = $mydb->FetchRow())
{
	foreach ($res as $key => $value)
	{
		if (FALSE == is_numeric( $key ))
		{
			$gen = new my_generator($value);
			$gen->CreateObjects();
			$gen->CreateXSLT();
			$gen->CreatePatterns();
			$gen->CreateTableSQL();
		}

	}
}
exit(0);

?>
