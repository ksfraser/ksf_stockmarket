<?php
require_once('roles.class.php');
require_once('local.php');
$table = new roles();
$mode = "update";
require_once('class.genericpage.php');
?>
