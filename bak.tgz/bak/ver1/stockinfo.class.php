<?php 
//this script may only be included - so its better to die if called directly.
if (strpos($_SERVER["SCRIPT_NAME"],basename(__FILE__)) !== false) {
  header("location: index.php");
  exit;
}

require_once('class.generictable.php');
require_once('stockinfo.class.inc.php');
class stockinfo extends generictable{
         function __constructor()
         {
         $this->querytablename = 'stockinfo';
         $this->fieldspec['52high']['metadata_id'] = '2515';
         $this->fieldspec['52high']['table_name'] = 'stockinfo';
         $this->fieldspec['52high']['column_name'] = '52high';
         $this->fieldspec['52high']['pretty_name'] = '52 Week High';
         $this->fieldspec['52high']['abstract_data_type'] = 'real';
         $this->fieldspec['52high']['db_data_type'] = 'float';
         $this->fieldspec['52high']['field_null'] = 'NO';
         $this->fieldspec['52high']['field_key'] = '0';
         $this->fieldspec['52high']['extra_sql'] = ' ';
         $this->fieldspec['52high']['html_form_type'] = 'float';
         $this->fieldspec['52high']['html_form_options'] = ' ';
         $this->fieldspec['52high']['html_form_explanation'] = ' ';
         $this->fieldspec['52high']['help_text'] = ' ';
         $this->fieldspec['52high']['mandatory_p'] = 'Y';
         $this->fieldspec['52high']['sort_key'] = '0';
         $this->fieldspec['52high']['form_sort_key'] = '0';
         $this->fieldspec['52high']['form_number'] = '1';
         $this->fieldspec['52high']['default_value'] = ' ';
         $this->fieldspec['52high']['field_toupper'] = 'NO';
         $this->fieldspec['52high']['validationprocname'] = ' ';
         $this->fieldspec['52high']['c_size'] = '8';
         $this->fieldspec['52high']['prikey'] = 'N';
         $this->fieldspec['52high']['noedit'] = 'N';
         $this->fieldspec['52high']['nodisplay'] = 'N';
         $this->fieldspec['52high']['c_unsigned'] = 'N';
         $this->fieldspec['52high']['c_zerofill'] = 'N';
         $this->fieldspec['52high']['c_auto_increment'] = 'N';
         $this->fieldspec['52high']['foreign_table'] = ' ';
         $this->fieldspec['52high']['foreign_key'] = ' ';
         $this->fieldspec['52high']['application'] = 'investing';
         $this->fieldspec['52high']['issearchable'] = '1';
         $this->fieldspec['52low']['metadata_id'] = '2516';
         $this->fieldspec['52low']['table_name'] = 'stockinfo';
         $this->fieldspec['52low']['column_name'] = '52low';
         $this->fieldspec['52low']['pretty_name'] = '52 Week Low';
         $this->fieldspec['52low']['abstract_data_type'] = 'real';
         $this->fieldspec['52low']['db_data_type'] = 'float';
         $this->fieldspec['52low']['field_null'] = 'NO';
         $this->fieldspec['52low']['field_key'] = '0';
         $this->fieldspec['52low']['extra_sql'] = ' ';
         $this->fieldspec['52low']['html_form_type'] = 'float';
         $this->fieldspec['52low']['html_form_options'] = ' ';
         $this->fieldspec['52low']['html_form_explanation'] = ' ';
         $this->fieldspec['52low']['help_text'] = ' ';
         $this->fieldspec['52low']['mandatory_p'] = 'Y';
         $this->fieldspec['52low']['sort_key'] = '0';
         $this->fieldspec['52low']['form_sort_key'] = '0';
         $this->fieldspec['52low']['form_number'] = '1';
         $this->fieldspec['52low']['default_value'] = ' ';
         $this->fieldspec['52low']['field_toupper'] = 'NO';
         $this->fieldspec['52low']['validationprocname'] = ' ';
         $this->fieldspec['52low']['c_size'] = '8';
         $this->fieldspec['52low']['prikey'] = 'N';
         $this->fieldspec['52low']['noedit'] = 'N';
         $this->fieldspec['52low']['nodisplay'] = 'N';
         $this->fieldspec['52low']['c_unsigned'] = 'N';
         $this->fieldspec['52low']['c_zerofill'] = 'N';
         $this->fieldspec['52low']['c_auto_increment'] = 'N';
         $this->fieldspec['52low']['foreign_table'] = ' ';
         $this->fieldspec['52low']['foreign_key'] = ' ';
         $this->fieldspec['52low']['application'] = 'investing';
         $this->fieldspec['52low']['issearchable'] = '1';
         $this->fieldspec['corporatename']['metadata_id'] = '2499';
         $this->fieldspec['corporatename']['table_name'] = 'stockinfo';
         $this->fieldspec['corporatename']['column_name'] = 'corporatename';
         $this->fieldspec['corporatename']['pretty_name'] = 'Corporate Name';
         $this->fieldspec['corporatename']['abstract_data_type'] = 'string';
         $this->fieldspec['corporatename']['db_data_type'] = 'varchar';
         $this->fieldspec['corporatename']['field_null'] = 'NO';
         $this->fieldspec['corporatename']['field_key'] = ' ';
         $this->fieldspec['corporatename']['extra_sql'] = ' ';
         $this->fieldspec['corporatename']['html_form_type'] = 'char';
         $this->fieldspec['corporatename']['html_form_options'] = ' ';
         $this->fieldspec['corporatename']['html_form_explanation'] = ' ';
         $this->fieldspec['corporatename']['help_text'] = ' ';
         $this->fieldspec['corporatename']['mandatory_p'] = 'n';
         $this->fieldspec['corporatename']['sort_key'] = '0';
         $this->fieldspec['corporatename']['form_sort_key'] = '0';
         $this->fieldspec['corporatename']['form_number'] = '1';
         $this->fieldspec['corporatename']['default_value'] = ' ';
         $this->fieldspec['corporatename']['field_toupper'] = 'NO';
         $this->fieldspec['corporatename']['validationprocname'] = ' ';
         $this->fieldspec['corporatename']['c_size'] = '255';
         $this->fieldspec['corporatename']['prikey'] = 'n';
         $this->fieldspec['corporatename']['noedit'] = 'n';
         $this->fieldspec['corporatename']['nodisplay'] = 'n';
         $this->fieldspec['corporatename']['c_unsigned'] = 'n';
         $this->fieldspec['corporatename']['c_zerofill'] = 'n';
         $this->fieldspec['corporatename']['c_auto_increment'] = 'n';
         $this->fieldspec['corporatename']['foreign_table'] = ' ';
         $this->fieldspec['corporatename']['foreign_key'] = ' ';
         $this->fieldspec['corporatename']['application'] = 'investing';
         $this->fieldspec['corporatename']['issearchable'] = '1';
         $this->fieldspec['exchange']['metadata_id'] = '2498';
         $this->fieldspec['exchange']['table_name'] = 'stockinfo';
         $this->fieldspec['exchange']['column_name'] = 'exchange';
         $this->fieldspec['exchange']['pretty_name'] = 'Stock Exchange';
         $this->fieldspec['exchange']['abstract_data_type'] = 'string';
         $this->fieldspec['exchange']['db_data_type'] = 'varchar';
         $this->fieldspec['exchange']['field_null'] = 'no';
         $this->fieldspec['exchange']['field_key'] = ' ';
         $this->fieldspec['exchange']['extra_sql'] = ' ';
         $this->fieldspec['exchange']['html_form_type'] = 'char';
         $this->fieldspec['exchange']['html_form_options'] = ' ';
         $this->fieldspec['exchange']['html_form_explanation'] = ' ';
         $this->fieldspec['exchange']['help_text'] = ' ';
         $this->fieldspec['exchange']['mandatory_p'] = 'y';
         $this->fieldspec['exchange']['sort_key'] = '0';
         $this->fieldspec['exchange']['form_sort_key'] = '0';
         $this->fieldspec['exchange']['form_number'] = '1';
         $this->fieldspec['exchange']['default_value'] = ' ';
         $this->fieldspec['exchange']['field_toupper'] = 'YES';
         $this->fieldspec['exchange']['validationprocname'] = ' ';
         $this->fieldspec['exchange']['c_size'] = '255';
         $this->fieldspec['exchange']['prikey'] = 'n';
         $this->fieldspec['exchange']['noedit'] = 'n';
         $this->fieldspec['exchange']['nodisplay'] = 'n';
         $this->fieldspec['exchange']['c_unsigned'] = 'n';
         $this->fieldspec['exchange']['c_zerofill'] = 'n';
         $this->fieldspec['exchange']['c_auto_increment'] = 'n';
         $this->fieldspec['exchange']['foreign_table'] = ' ';
         $this->fieldspec['exchange']['foreign_key'] = ' ';
         $this->fieldspec['exchange']['application'] = 'investing';
         $this->fieldspec['exchange']['issearchable'] = '1';
         $this->fieldspec['high']['metadata_id'] = '2518';
         $this->fieldspec['high']['table_name'] = 'stockinfo';
         $this->fieldspec['high']['column_name'] = 'high';
         $this->fieldspec['high']['pretty_name'] = 'High';
         $this->fieldspec['high']['abstract_data_type'] = 'real';
         $this->fieldspec['high']['db_data_type'] = 'float';
         $this->fieldspec['high']['field_null'] = 'NO';
         $this->fieldspec['high']['field_key'] = '0';
         $this->fieldspec['high']['extra_sql'] = ' ';
         $this->fieldspec['high']['html_form_type'] = 'float';
         $this->fieldspec['high']['html_form_options'] = ' ';
         $this->fieldspec['high']['html_form_explanation'] = ' ';
         $this->fieldspec['high']['help_text'] = ' ';
         $this->fieldspec['high']['mandatory_p'] = 'Y';
         $this->fieldspec['high']['sort_key'] = '0';
         $this->fieldspec['high']['form_sort_key'] = '0';
         $this->fieldspec['high']['form_number'] = '1';
         $this->fieldspec['high']['default_value'] = ' ';
         $this->fieldspec['high']['field_toupper'] = 'NO';
         $this->fieldspec['high']['validationprocname'] = ' ';
         $this->fieldspec['high']['c_size'] = '8';
         $this->fieldspec['high']['prikey'] = 'N';
         $this->fieldspec['high']['noedit'] = 'N';
         $this->fieldspec['high']['nodisplay'] = 'N';
         $this->fieldspec['high']['c_unsigned'] = 'N';
         $this->fieldspec['high']['c_zerofill'] = 'N';
         $this->fieldspec['high']['c_auto_increment'] = 'N';
         $this->fieldspec['high']['foreign_table'] = ' ';
         $this->fieldspec['high']['foreign_key'] = ' ';
         $this->fieldspec['high']['application'] = 'investing';
         $this->fieldspec['high']['issearchable'] = '1';
         $this->fieldspec['low']['metadata_id'] = '2517';
         $this->fieldspec['low']['table_name'] = 'stockinfo';
         $this->fieldspec['low']['column_name'] = 'low';
         $this->fieldspec['low']['pretty_name'] = 'Low';
         $this->fieldspec['low']['abstract_data_type'] = 'real';
         $this->fieldspec['low']['db_data_type'] = 'float';
         $this->fieldspec['low']['field_null'] = 'NO';
         $this->fieldspec['low']['field_key'] = '0';
         $this->fieldspec['low']['extra_sql'] = ' ';
         $this->fieldspec['low']['html_form_type'] = 'float';
         $this->fieldspec['low']['html_form_options'] = ' ';
         $this->fieldspec['low']['html_form_explanation'] = ' ';
         $this->fieldspec['low']['help_text'] = ' ';
         $this->fieldspec['low']['mandatory_p'] = 'Y';
         $this->fieldspec['low']['sort_key'] = '0';
         $this->fieldspec['low']['form_sort_key'] = '0';
         $this->fieldspec['low']['form_number'] = '1';
         $this->fieldspec['low']['default_value'] = ' ';
         $this->fieldspec['low']['field_toupper'] = 'NO';
         $this->fieldspec['low']['validationprocname'] = ' ';
         $this->fieldspec['low']['c_size'] = '8';
         $this->fieldspec['low']['prikey'] = 'N';
         $this->fieldspec['low']['noedit'] = 'N';
         $this->fieldspec['low']['nodisplay'] = 'N';
         $this->fieldspec['low']['c_unsigned'] = 'N';
         $this->fieldspec['low']['c_zerofill'] = 'N';
         $this->fieldspec['low']['c_auto_increment'] = 'N';
         $this->fieldspec['low']['foreign_table'] = ' ';
         $this->fieldspec['low']['foreign_key'] = ' ';
         $this->fieldspec['low']['application'] = 'investing';
         $this->fieldspec['low']['issearchable'] = '1';
         $this->fieldspec['stocksymbol']['metadata_id'] = '2497';
         $this->fieldspec['stocksymbol']['table_name'] = 'stockinfo';
         $this->fieldspec['stocksymbol']['column_name'] = 'stocksymbol';
         $this->fieldspec['stocksymbol']['pretty_name'] = 'Stock Symbol';
         $this->fieldspec['stocksymbol']['abstract_data_type'] = 'string';
         $this->fieldspec['stocksymbol']['db_data_type'] = 'char';
         $this->fieldspec['stocksymbol']['field_null'] = 'NO';
         $this->fieldspec['stocksymbol']['field_key'] = ' ';
         $this->fieldspec['stocksymbol']['extra_sql'] = ' ';
         $this->fieldspec['stocksymbol']['html_form_type'] = 'char';
         $this->fieldspec['stocksymbol']['html_form_options'] = ' ';
         $this->fieldspec['stocksymbol']['html_form_explanation'] = ' ';
         $this->fieldspec['stocksymbol']['help_text'] = ' ';
         $this->fieldspec['stocksymbol']['mandatory_p'] = 'y';
         $this->fieldspec['stocksymbol']['sort_key'] = '0';
         $this->fieldspec['stocksymbol']['form_sort_key'] = '0';
         $this->fieldspec['stocksymbol']['form_number'] = '1';
         $this->fieldspec['stocksymbol']['default_value'] = ' ';
         $this->fieldspec['stocksymbol']['field_toupper'] = 'YES';
         $this->fieldspec['stocksymbol']['validationprocname'] = ' ';
         $this->fieldspec['stocksymbol']['c_size'] = '4';
         $this->fieldspec['stocksymbol']['prikey'] = 'y';
         $this->fieldspec['stocksymbol']['noedit'] = 'n';
         $this->fieldspec['stocksymbol']['nodisplay'] = 'n';
         $this->fieldspec['stocksymbol']['c_unsigned'] = 'n';
         $this->fieldspec['stocksymbol']['c_zerofill'] = 'n';
         $this->fieldspec['stocksymbol']['c_auto_increment'] = 'n';
         $this->fieldspec['stocksymbol']['foreign_table'] = ' ';
         $this->fieldspec['stocksymbol']['foreign_key'] = ' ';
         $this->fieldspec['stocksymbol']['application'] = 'investing';
         $this->fieldspec['stocksymbol']['issearchable'] = '1';
         $this->fieldlist = array('52high', '52low', 'corporatename', 'exchange', 'high', 'low', 'stocksymbol');
	         return SUCCESS;
         }
         function stockinfo()
         { //For older php which doesn't have constructor
         return $this->__constructor();
         }
         function Push()
         {
	         $_SESSION['stockinfo'] = serialize($this);
	         return SUCCESS;
         }
         function Pop()
         {
                 //Can't do this in self - this is how to do it outside
	       //  $this = unserialize($_SESSION['stockinfo']);
	         return SUCCESS;
         }
         function Setstocksymbol($value)
         {
                  $this->fieldspec['stocksymbol']['VALUE'] = $value;
	          return SUCCESS;
         }
         function Getstocksymbol()
         {
                    return $this->fieldspec['stocksymbol']['VALUE'];
         }
         function Validatestocksymbol()
         {
         }
} /* class stockinfo */
