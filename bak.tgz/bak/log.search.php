<?php
require_once('log.class.php');
require_once('local.php');
$table = new log();
$mode = "search";
require_once('controller/controller.php');
?>
