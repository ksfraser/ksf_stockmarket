---
--- Table struct for table stockinfo
---
DROP TABLE IF EXISTS `stockinfo`;
CREATE TABLE `stockinfo` (
`52high` float(8)   NOT NULL  default ' ' comment '52 Week High',
`52low` float(8)   NOT NULL  default ' ' comment '52 Week Low',
`corporatename` varchar(255)   NOT NULL  default ' ' comment 'Corporate Name',
`exchange` varchar(255)   NOT NULL  default ' ' comment 'Stock Exchange',
`high` float(8)   NOT NULL  default ' ' comment 'High',
`low` float(8)   NOT NULL  default ' ' comment 'Low',
`stocksymbol` char(4)   NOT NULL  default ' ' comment 'Stock Symbol'
PRIMARY KEY ('')
) ENGINE=myIsam DEFAULT CHARSET=latin1;
