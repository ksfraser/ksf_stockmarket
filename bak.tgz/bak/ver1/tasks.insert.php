<?php
require_once('tasks.class.php');
require_once('local.php');
$table = new tasks();
$mode = "insert";
require_once('class.genericpage.php');
?>
