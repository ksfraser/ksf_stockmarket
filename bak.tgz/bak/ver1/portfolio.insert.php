<?php
require_once('portfolio.class.php');
require_once('local.php');
$table = new portfolio();
$mode = "insert";
require_once('class.genericpage.php');
?>
