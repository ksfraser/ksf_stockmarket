<?php

	require_once( 'view/form.php');
	require_once( 'view/entry.php');
	require_once( 'view/table.php');
	require_once( 'view/tablerows.php');
	require_once( 'view/radiobutton.php');
	require_once( 'view/atomic.php');

?>
