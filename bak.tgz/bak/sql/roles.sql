---
--- Table struct for table roles
---
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
`roledescription` varchar(45)   NOT NULL  default ' ' comment 'Role Description',
`rolenumber` integer(8)   NOT NULL  default '0' comment 'Role Index'
PRIMARY KEY (``)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
