---
--- Table struct for table roletask
---
DROP TABLE IF EXISTS `roletask`;
CREATE TABLE `roletask` (
`idroletask` integer(8)   NOT NULL  default '0' comment 'Index',
`idtasks` integer(8)   NOT NULL  default ' ' comment 'Task',
`rolenumber` integer(8)   NOT NULL  default ' ' comment 'Role'
PRIMARY KEY ('idroletask')
) ENGINE=myIsam DEFAULT CHARSET=latin1;
